-- ============ WIPE ============
DROP TABLE IF EXISTS public.thread_memory CASCADE;
DROP TABLE IF EXISTS public.artifact_versions CASCADE;
DROP TABLE IF EXISTS public.artifacts CASCADE;
DROP TABLE IF EXISTS public.messages CASCADE;
DROP TABLE IF EXISTS public.threads CASCADE;
DROP TABLE IF EXISTS public.agent_settings CASCADE;
DROP TABLE IF EXISTS public.user_roles CASCADE;
DROP TYPE IF EXISTS public.app_role CASCADE;

-- ============ SHARED FUNCTIONS ============
CREATE OR REPLACE FUNCTION public.tg_set_updated_at()
RETURNS trigger LANGUAGE plpgsql SET search_path = public AS $$
BEGIN NEW.updated_at = now(); RETURN NEW; END; $$;

-- ============ ROLES ============
CREATE TYPE public.app_role AS ENUM ('admin', 'moderator', 'user');

CREATE TABLE public.user_roles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  role public.app_role NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (user_id, role)
);
GRANT SELECT ON public.user_roles TO authenticated;
GRANT ALL ON public.user_roles TO service_role;
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;
CREATE POLICY "Users read own roles" ON public.user_roles
  FOR SELECT TO authenticated USING (auth.uid() = user_id);

CREATE OR REPLACE FUNCTION public.has_role(_user_id uuid, _role public.app_role)
RETURNS boolean LANGUAGE sql STABLE SECURITY DEFINER SET search_path = public AS $$
  SELECT EXISTS (SELECT 1 FROM public.user_roles WHERE user_id = _user_id AND role = _role)
$$;

-- ============ THREADS ============
CREATE TABLE public.threads (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  title text NOT NULL DEFAULT 'New chat',
  model text NOT NULL DEFAULT 'openai/gpt-5.5',
  temperature numeric NOT NULL DEFAULT 0.7,
  system_prompt text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.threads TO authenticated;
GRANT ALL ON public.threads TO service_role;
ALTER TABLE public.threads ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own threads all" ON public.threads
  FOR ALL TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE TRIGGER threads_set_updated_at BEFORE UPDATE ON public.threads
  FOR EACH ROW EXECUTE FUNCTION public.tg_set_updated_at();
CREATE INDEX threads_user_id_idx ON public.threads (user_id, updated_at DESC);

-- ============ MESSAGES ============
CREATE TABLE public.messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  thread_id uuid NOT NULL REFERENCES public.threads(id) ON DELETE CASCADE,
  role text NOT NULL,
  parts jsonb NOT NULL DEFAULT '[]'::jsonb,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.messages TO authenticated;
GRANT ALL ON public.messages TO service_role;
ALTER TABLE public.messages ENABLE ROW LEVEL SECURITY;
CREATE POLICY "messages via own thread" ON public.messages
  FOR ALL TO authenticated
  USING (EXISTS (SELECT 1 FROM public.threads t WHERE t.id = messages.thread_id AND t.user_id = auth.uid()))
  WITH CHECK (EXISTS (SELECT 1 FROM public.threads t WHERE t.id = messages.thread_id AND t.user_id = auth.uid()));
CREATE INDEX messages_thread_id_idx ON public.messages (thread_id, created_at);

-- ============ ARTIFACTS ============
CREATE TABLE public.artifacts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  thread_id uuid NOT NULL REFERENCES public.threads(id) ON DELETE CASCADE,
  message_id uuid REFERENCES public.messages(id) ON DELETE SET NULL,
  kind text NOT NULL,
  title text NOT NULL DEFAULT 'Untitled',
  content text NOT NULL DEFAULT '',
  files jsonb NOT NULL DEFAULT '[]'::jsonb,
  entry_path text,
  is_public boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.artifacts TO authenticated;
GRANT SELECT ON public.artifacts TO anon;
GRANT ALL ON public.artifacts TO service_role;
ALTER TABLE public.artifacts ENABLE ROW LEVEL SECURITY;
CREATE POLICY "artifacts via own thread" ON public.artifacts
  FOR ALL TO authenticated
  USING (EXISTS (SELECT 1 FROM public.threads t WHERE t.id = artifacts.thread_id AND t.user_id = auth.uid()))
  WITH CHECK (EXISTS (SELECT 1 FROM public.threads t WHERE t.id = artifacts.thread_id AND t.user_id = auth.uid()));
CREATE POLICY "public artifacts readable" ON public.artifacts
  FOR SELECT TO anon USING (is_public = true);
CREATE INDEX artifacts_thread_id_idx ON public.artifacts (thread_id, created_at DESC);

-- ============ ARTIFACT VERSIONS ============
CREATE TABLE public.artifact_versions (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  artifact_id uuid NOT NULL REFERENCES public.artifacts(id) ON DELETE CASCADE,
  message_id uuid REFERENCES public.messages(id) ON DELETE SET NULL,
  title text,
  content text NOT NULL DEFAULT '',
  files jsonb,
  entry_path text,
  label text,
  source text NOT NULL DEFAULT 'tool',
  created_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.artifact_versions TO authenticated;
GRANT ALL ON public.artifact_versions TO service_role;
ALTER TABLE public.artifact_versions ENABLE ROW LEVEL SECURITY;
CREATE POLICY "artifact_versions via own thread" ON public.artifact_versions
  FOR ALL TO authenticated
  USING (EXISTS (SELECT 1 FROM public.artifacts a JOIN public.threads t ON t.id = a.thread_id
                 WHERE a.id = artifact_versions.artifact_id AND t.user_id = auth.uid()))
  WITH CHECK (EXISTS (SELECT 1 FROM public.artifacts a JOIN public.threads t ON t.id = a.thread_id
                 WHERE a.id = artifact_versions.artifact_id AND t.user_id = auth.uid()));
CREATE INDEX artifact_versions_artifact_id_idx ON public.artifact_versions (artifact_id, created_at DESC);

CREATE OR REPLACE FUNCTION public.tg_snapshot_artifact_version()
RETURNS trigger LANGUAGE plpgsql SET search_path = public AS $$
BEGIN
  IF NEW.content IS DISTINCT FROM OLD.content
     OR NEW.files IS DISTINCT FROM OLD.files
     OR NEW.entry_path IS DISTINCT FROM OLD.entry_path THEN
    INSERT INTO public.artifact_versions (artifact_id, content, files, entry_path, title)
    VALUES (OLD.id, OLD.content, OLD.files, OLD.entry_path, OLD.title);
  END IF;
  RETURN NEW;
END;
$$;
CREATE TRIGGER artifacts_snapshot_version BEFORE UPDATE ON public.artifacts
  FOR EACH ROW EXECUTE FUNCTION public.tg_snapshot_artifact_version();

-- ============ THREAD MEMORY ============
CREATE TABLE public.thread_memory (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  thread_id uuid NOT NULL REFERENCES public.threads(id) ON DELETE CASCADE,
  key text NOT NULL,
  value jsonb NOT NULL,
  updated_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (thread_id, key)
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.thread_memory TO authenticated;
GRANT ALL ON public.thread_memory TO service_role;
ALTER TABLE public.thread_memory ENABLE ROW LEVEL SECURITY;
CREATE POLICY "thread_memory via own thread" ON public.thread_memory
  FOR ALL TO authenticated
  USING (EXISTS (SELECT 1 FROM public.threads t WHERE t.id = thread_memory.thread_id AND t.user_id = auth.uid()))
  WITH CHECK (EXISTS (SELECT 1 FROM public.threads t WHERE t.id = thread_memory.thread_id AND t.user_id = auth.uid()));
CREATE TRIGGER thread_memory_set_updated_at BEFORE UPDATE ON public.thread_memory
  FOR EACH ROW EXECUTE FUNCTION public.tg_set_updated_at();

-- ============ AGENT SETTINGS ============
CREATE TABLE public.agent_settings (
  user_id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  default_model text NOT NULL DEFAULT 'openai/gpt-5.5',
  default_temperature numeric NOT NULL DEFAULT 0.7,
  default_system_prompt text NOT NULL DEFAULT 'You are Builder, a helpful, precise AI agent. When the user asks for a webpage, component, or design, respond with a short explanation and then emit a full self-contained HTML document inside a ```html fenced block so it can be rendered in the live canvas. Use inline <style> and modern, tasteful design. Prefer semantic HTML and accessible markup.',
  tools jsonb NOT NULL DEFAULT '{"web_search": false, "create_artifact": true, "code_interpreter": false}'::jsonb,
  updated_at timestamptz NOT NULL DEFAULT now()
);
GRANT SELECT, INSERT, UPDATE, DELETE ON public.agent_settings TO authenticated;
GRANT ALL ON public.agent_settings TO service_role;
ALTER TABLE public.agent_settings ENABLE ROW LEVEL SECURITY;
CREATE POLICY "own agent settings" ON public.agent_settings
  FOR ALL TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);
CREATE TRIGGER agent_settings_set_updated_at BEFORE UPDATE ON public.agent_settings
  FOR EACH ROW EXECUTE FUNCTION public.tg_set_updated_at();