ALTER TABLE public.threads ALTER COLUMN model SET DEFAULT 'mistral-large-latest';
ALTER TABLE public.agent_settings ALTER COLUMN default_model SET DEFAULT 'mistral-large-latest';

UPDATE public.threads SET model = 'mistral-large-latest' WHERE model LIKE 'openai/%' OR model LIKE 'google/%';
UPDATE public.agent_settings SET default_model = 'mistral-large-latest' WHERE default_model LIKE 'openai/%' OR default_model LIKE 'google/%';

REVOKE INSERT, UPDATE, DELETE ON public.user_roles FROM anon;
GRANT SELECT ON public.user_roles TO authenticated;
GRANT ALL ON public.user_roles TO service_role;