/**
 * Ship e2e subset: landing + chat (no login gate anywhere).
 *
 *   bun run test:e2e:ship
 */
import { spawnSync } from "node:child_process";

const files = [
  "e2e/landing.pw.ts",
  "e2e/ship-chat.pw.ts",
  "e2e/full-journey.pw.ts",
  "e2e/no-auth-gate.pw.ts",
  "e2e/mobile-shell.pw.ts",
  "e2e/share-public.pw.ts",
];

// Use the locally installed Playwright binary — `bunx playwright@x.y.z` downloads a
// second copy and Playwright then refuses to run ("two different versions").
const result = spawnSync("node_modules/.bin/playwright", ["test", ...files], {
  stdio: "inherit",
  env: process.env,
  cwd: process.cwd(),
});
if (result.error) {
  console.error(result.error);
  process.exit(1);
}
process.exit(result.status ?? 1);
