import { test, expect } from "@playwright/test";

/**
 * Guard: the app must have NO login gate at all.
 * - /auth is permanently gone (404 chrome, never a sign-in form)
 * - every app route loads straight into the workspace, no redirect to /auth
 * - no sign-in / access-code UI anywhere on the public surface
 */
const APP_ROUTES = ["/chat", "/builder", "/templates", "/"];

test.describe("No auth gate", () => {
  test("/auth no longer exists", async ({ page }) => {
    const res = await page.goto("/auth");
    expect(res).toBeTruthy();
    expect(res!.status()).toBeLessThan(500);
    await expect(page.getByTestId("auth-sign-in")).toHaveCount(0);
    await expect(page.getByPlaceholder(/prístupový kód|access code/i)).toHaveCount(0);
    await expect(page.getByRole("button", { name: /^sign in$/i })).toHaveCount(0);
  });

  test("/auth?next=/builder does not render a gate", async ({ page }) => {
    await page.goto("/auth?next=%2Fbuilder");
    await expect(page.getByTestId("auth-sign-in")).toHaveCount(0);
    expect(await page.locator("input[type=password]").count()).toBe(0);
  });

  for (const route of APP_ROUTES) {
    test(`${route} loads without redirecting to /auth`, async ({ page }) => {
      await page.context().clearCookies();
      await page.addInitScript(() => {
        try {
          localStorage.clear();
          sessionStorage.clear();
        } catch {
          /* ignore */
        }
      });
      const res = await page.goto(route);
      expect(res!.status()).toBeLessThan(500);
      await page.waitForLoadState("domcontentloaded");
      await page.waitForTimeout(2_000);
      expect(page.url()).not.toMatch(/\/auth/);
      expect(await page.locator("input[type=password]").count()).toBe(0);
    });
  }

  test("chat workspace reaches the composer with no credentials", async ({ page }) => {
    await page.goto("/chat");
    await expect(page.getByTestId("chat-composer")).toBeVisible({ timeout: 45_000 });
    expect(page.url()).not.toMatch(/\/auth/);
  });
});
