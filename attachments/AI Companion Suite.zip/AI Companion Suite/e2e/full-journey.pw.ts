import { test, expect, type Page } from "@playwright/test";

/** Full public product journey — start → end without AI stream or login. */
const MISSING_PUBLIC_ID = "00000000-0000-4000-8000-000000000001";
const TEMPLATE_SLUG = "saas-landing";

/** Clear Supabase session (localStorage) so public gates stay unauthenticated. */
async function clearBrowserSession(page: Page) {
  await page.context().clearCookies();
  await page.addInitScript(() => {
    try {
      localStorage.clear();
      sessionStorage.clear();
    } catch {
      /* ignore */
    }
  });
  // Also clear if a page is already open
  try {
    await page.evaluate(() => {
      try {
        localStorage.clear();
        sessionStorage.clear();
      } catch {
        /* ignore */
      }
    });
  } catch {
    /* no page yet */
  }
}

test.describe("Full app journey (public surface)", () => {
  test("1 · landing hero, how-it-works, features, footer", async ({ page }) => {
    const res = await page.goto("/");
    expect(res).toBeTruthy();
    expect(res!.status()).toBeLessThan(500);
    const hero = page.getByTestId("landing-hero");
    await expect(hero).toBeVisible({ timeout: 20_000 });
    await expect(hero.getByRole("heading", { level: 1 })).toContainText(/build/i);
    await expect(hero.getByRole("link", { name: /open builder/i })).toBeVisible();
    await expect(hero.getByRole("link", { name: /browse templates/i })).toBeVisible();
    await expect(hero.getByText("Starter")).toBeVisible();
    await expect(hero.getByText("Pro")).toBeVisible();
    await expect(hero.getByText("Team")).toBeVisible();
    const how = page.getByTestId("landing-how-it-works");
    await expect(how).toBeVisible();
    await expect(how.getByRole("heading", { name: /how it works/i })).toBeVisible();
    await expect(how.getByText("Chat")).toBeVisible();
    await expect(how.getByText("Canvas")).toBeVisible();
    await expect(how.getByText("Share")).toBeVisible();
    const features = page.getByTestId("landing-feature-grid");
    await expect(features).toBeVisible();
    await expect(
      features.getByRole("heading", { name: /everything the canvas already does/i }),
    ).toBeVisible();
    await expect(page.getByRole("link", { name: /^templates$/i }).first()).toBeVisible();
    await expect(page.getByRole("link", { name: /open builder/i }).first()).toBeVisible();
  });

  test("2 · Open Builder CTA opens the app with no gate", async ({ page }) => {
    test.setTimeout(90_000);
    await clearBrowserSession(page);
    await page.goto("/");
    await expect(page.getByTestId("landing-hero")).toBeVisible({ timeout: 20_000 });
    await page.getByRole("link", { name: /open builder/i }).click();
    await page.waitForURL(/\/(chat|builder)/, { timeout: 30_000 });
    expect(page.url()).not.toMatch(/\/auth/);
  });

  test("3 · Browse templates → open detail", async ({ page }) => {
    await page.goto("/");
    await expect(page.getByTestId("landing-hero")).toBeVisible({ timeout: 20_000 });
    await page.getByRole("link", { name: /browse templates/i }).click();
    await page.waitForURL(/\/templates/, { timeout: 15_000 });
    await expect(page.getByRole("heading", { level: 1, name: /^templates$/i })).toBeVisible({
      timeout: 20_000,
    });
    await expect(page.getByRole("link", { name: /saas landing/i })).toBeVisible();
    await page.getByRole("link", { name: /saas landing/i }).click();
    await page.waitForURL(new RegExp(`/templates/${TEMPLATE_SLUG}`), { timeout: 15_000 });
    await expect(page.getByRole("heading", { level: 1, name: /saas landing/i })).toBeVisible({
      timeout: 15_000,
    });
    await expect(page.getByRole("button", { name: /use template/i })).toBeVisible();
  });

  test("4 · Use template without session → straight into chat", async ({ page }) => {
    await clearBrowserSession(page);
    await page.goto(`/templates/${TEMPLATE_SLUG}`);
    await expect(page.getByRole("heading", { level: 1, name: /saas landing/i })).toBeVisible({
      timeout: 20_000,
    });
    const useBtn = page.getByRole("button", { name: /use template/i });
    await expect(useBtn).toBeEnabled();
    await Promise.all([
      page.waitForURL((url) => url.pathname.startsWith("/chat"), { timeout: 30_000 }),
      useBtn.click(),
    ]);
    expect(page.url()).not.toMatch(/\/auth/);
  });

  test("5 · /auth is permanently removed", async ({ page }) => {
    await clearBrowserSession(page);
    const res = await page.goto("/auth");
    expect(res!.status()).toBeLessThan(500);
    await expect(page.getByTestId("auth-sign-in")).toHaveCount(0);
    expect(await page.locator("input[type=password]").count()).toBe(0);
  });

  test("6 · /chat is not protected by any gate", async ({ page }) => {
    await clearBrowserSession(page);
    await page.goto("/chat");
    await page.waitForLoadState("domcontentloaded");
    await page.waitForTimeout(2_000);
    expect(page.url()).not.toMatch(/\/auth/);
  });

  test("7 · /api/ai-status health probe", async ({ request }) => {
    const res = await request.get("/api/ai-status");
    expect(res.status()).toBe(200);
    const body = await res.json();
    expect(body.ok).toBe(true);
    expect(body.provider).toBe("mistral");
    expect(body.lovableGatewayDisabled).toBe(true);
    expect(body.tools).toEqual(
      expect.arrayContaining([
        "create_artifact",
        "edit_file",
        "read_artifact",
        "plan_steps",
        "launch_site",
      ]),
    );
  });

  test("8 · PWA assets respond", async ({ request }) => {
    for (const path of [
      "/manifest.webmanifest",
      "/sw.js",
      "/offline.html",
      "/icons/icon-192.png",
    ]) {
      expect((await request.get(path)).status(), path).toBe(200);
    }
  });

  test("9 · Public artifact missing id shows 404 chrome", async ({ page }) => {
    test.setTimeout(60_000);
    await page.goto(`/a/${MISSING_PUBLIC_ID}`);
    await expect(page.getByTestId("public-artifact-not-found")).toBeVisible({ timeout: 30_000 });
    await expect(page.getByTestId("public-artifact-not-found")).toContainText("404");
  });

  test("10 · Preview rejects traversal + unknown private artifact", async ({ request }) => {
    const traversal = await request.get(`/preview/${MISSING_PUBLIC_ID}/../etc/passwd`);
    expect([400, 404, 500]).toContain(traversal.status());
    expect(await traversal.text()).not.toContain("root:");
    const missing = await request.get(`/preview/00000000-0000-4000-8000-000000000099/index.html`);
    expect(missing.status()).toBe(404);
  });

  test("11 · Mobile 390px: landing + templates no overflow", async ({ page }) => {
    await page.setViewportSize({ width: 390, height: 844 });
    await page.goto("/");
    await expect(page.getByTestId("landing-hero")).toBeVisible({ timeout: 20_000 });
    await assertNoCatastrophicOverflow(page);
    await page.goto("/templates");
    await expect(page.getByRole("heading", { level: 1, name: /^templates$/i })).toBeVisible({
      timeout: 20_000,
    });
    await assertNoCatastrophicOverflow(page);
  });

  test("12 · Deep links: header Templates + Open builder from landing", async ({ page }) => {
    await page.goto("/");
    await expect(page.getByTestId("landing-hero")).toBeVisible({ timeout: 20_000 });
    await page
      .locator("header")
      .getByRole("link", { name: /^templates$/i })
      .click();
    await page.waitForURL(/\/templates/, { timeout: 15_000 });
    await expect(page.getByRole("heading", { level: 1, name: /^templates$/i })).toBeVisible();
    await page
      .getByRole("link", { name: /open builder/i })
      .first()
      .click();
    await page.waitForURL(/\/(chat|builder)/, { timeout: 20_000 });
    expect(page.url()).not.toMatch(/\/auth/);
  });
});

async function assertNoCatastrophicOverflow(page: Page) {
  const { scrollWidth, clientWidth } = await page.evaluate(() => ({
    scrollWidth: document.documentElement.scrollWidth,
    clientWidth: document.documentElement.clientWidth,
  }));
  expect(scrollWidth).toBeLessThanOrEqual(clientWidth + 24);
}
