import { test, expect } from "@playwright/test";

/**
 * Ship-loop chat happy path — the app has NO login gate.
 * - /chat opens the workspace directly
 * - /api/ai-status health
 */
test.describe("Ship chat", () => {
  test("/chat opens the workspace without any gate", async ({ page }) => {
    await page.context().clearCookies();
    await page.goto("/chat");
    await page.waitForLoadState("domcontentloaded");
    expect(page.url()).not.toMatch(/\/auth/);
    await expect(page.getByTestId("chat-composer")).toBeVisible({ timeout: 45_000 });
  });

  test("composer sends an authenticated request and renders the stream", async ({ page }) => {
    let authorization = "";
    await page.route("**/api/chat", async (route) => {
      authorization = route.request().headers()["authorization"] ?? "";
      const body = [
        'data: {"type":"start","messageId":"assistant-e2e"}',
        'data: {"type":"text-start","id":"text-e2e"}',
        'data: {"type":"text-delta","id":"text-e2e","delta":"STREAM_E2E_OK"}',
        'data: {"type":"text-end","id":"text-e2e"}',
        'data: {"type":"finish"}',
        "data: [DONE]",
        "",
      ].join("\n\n");
      await route.fulfill({
        status: 200,
        contentType: "text/event-stream",
        headers: { "x-vercel-ai-ui-message-stream": "v1" },
        body,
      });
    });

    await page.goto("/chat");
    const composer = page.getByTestId("chat-composer");
    await expect(composer).toBeVisible({ timeout: 45_000 });
    const tour = page.getByRole("dialog", { name: "Builder tour" });
    if (await tour.isVisible()) await tour.getByRole("button", { name: "Skip" }).click();

    await composer.getByRole("textbox").fill("Stream integrity check");
    await composer.getByRole("textbox").press("Enter");

    await expect(page.getByText("STREAM_E2E_OK", { exact: true })).toBeVisible();
    expect(authorization).toMatch(/^Bearer /);
  });

  test("/api/ai-status reports mistral builder health", async ({ request }) => {
    const res = await request.get("/api/ai-status");
    expect(res.status()).toBe(200);
    const body = (await res.json()) as {
      ok: boolean;
      provider: string;
      lovableGatewayDisabled: boolean;
    };
    expect(body.ok).toBe(true);
    expect(body.provider).toBe("mistral");
    expect(body.lovableGatewayDisabled).toBe(true);
  });
});
