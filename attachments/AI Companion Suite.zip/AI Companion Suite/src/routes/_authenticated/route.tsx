import { createFileRoute, Outlet } from "@tanstack/react-router";
import { supabase } from "@/integrations/supabase/client";
import { ensureWorkspaceAccessToken } from "@/lib/workspace-session";

/**
 * There is NO login gate. If the browser has no session yet we silently open
 * the shared workspace session on the server and continue — never redirect.
 */
export const Route = createFileRoute("/_authenticated")({
  ssr: false,
  beforeLoad: async () => {
    try {
      const token = await ensureWorkspaceAccessToken({ allowMissing: true });
      if (!token) return { user: null };
      const { data } = await supabase.auth.getUser(token);
      return { user: data.user ?? null };
    } catch (e) {
      console.error("[workspace] session bootstrap failed:", e);
      return { user: null };
    }
  },
  component: () => <Outlet />,
});
