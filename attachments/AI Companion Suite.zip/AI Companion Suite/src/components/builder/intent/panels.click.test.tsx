// @vitest-environment happy-dom
import * as React from "react";
import { act } from "react";
import { createRoot, type Root } from "react-dom/client";
import { describe, it, expect, beforeEach, afterEach, vi } from "vitest";
import type { RawNode } from "@/lib/builder/semantic-intent/types";
import {
  defaultIntent,
  seedIntent,
  type GuardViolation,
  type IntentConflict,
  type RippleProposal,
  type RippleRule,
  type TimelineEntry,
} from "@/lib/builder/intent";
import { IntentPanel } from "./IntentPanel";
import { GuardChips } from "./GuardChips";
import { RipplePreview } from "./RipplePreview";
import { IntentTimelinePanel } from "./IntentTimelinePanel";

declare global {
  // eslint-disable-next-line no-var
  var IS_REACT_ACT_ENVIRONMENT: boolean;
}
globalThis.IS_REACT_ACT_ENVIRONMENT = true;

let container: HTMLDivElement;
let root: Root;

beforeEach(() => {
  container = document.createElement("div");
  document.body.appendChild(container);
  root = createRoot(container);
});

afterEach(() => {
  act(() => root.unmount());
  container.remove();
});

function render(ui: React.ReactElement) {
  act(() => root.render(ui));
}

function q(testId: string): HTMLElement {
  const el = container.querySelector<HTMLElement>(`[data-testid="${testId}"]`);
  if (!el) throw new Error(`missing [data-testid="${testId}"]`);
  return el;
}

function click(testId: string) {
  act(() => {
    q(testId).dispatchEvent(new window.MouseEvent("click", { bubbles: true }));
  });
}

/* ------------------------------------------------------------------ */

describe("IntentPanel — every chip is wired", () => {
  const node: RawNode = {
    id: "cta",
    type: "button",
    text: "Buy",
    intent: defaultIntent("primary-cta", "vision"),
  };

  it("renders the empty state without a selection", () => {
    render(<IntentPanel node={null} onRedefineRole={() => {}} />);
    expect(q("intent-panel-empty").textContent).toContain("Select a node");
  });

  it("shows provenance for each claim", () => {
    render(<IntentPanel node={node} onRedefineRole={() => {}} />);
    const text = q("intent-panel").textContent ?? "";
    expect(text).toContain("primary-cta");
    expect(text).toContain("vision");
    expect(text).toContain("cta");
  });

  it("clicking an inactive role chip redefines the role", () => {
    const onRedefineRole = vi.fn();
    render(<IntentPanel node={node} onRedefineRole={onRedefineRole} />);
    click("intent-role-chip-secondary-cta");
    expect(onRedefineRole).toHaveBeenCalledWith("cta", "secondary-cta");
  });

  it("clicking the active chip unselects back to the default (chip contract)", () => {
    const onRedefineRole = vi.fn();
    render(<IntentPanel node={node} onRedefineRole={onRedefineRole} />);
    click("intent-role-chip-primary-cta");
    expect(onRedefineRole).toHaveBeenCalledWith("cta", "unknown");
  });

  it("every role chip is clickable", () => {
    const onRedefineRole = vi.fn();
    render(<IntentPanel node={node} onRedefineRole={onRedefineRole} />);
    const chips = container.querySelectorAll<HTMLElement>('[data-testid^="intent-role-chip-"]');
    expect(chips.length).toBeGreaterThan(5);
    act(() => {
      chips.forEach((c) => c.dispatchEvent(new window.MouseEvent("click", { bubbles: true })));
    });
    expect(onRedefineRole).toHaveBeenCalledTimes(chips.length);
  });
});

describe("GuardChips — fix, select, redefine, keep", () => {
  const violations: GuardViolation[] = [
    {
      id: "touch-cta",
      nodeId: "cta",
      severity: "contract",
      message: "Touch target below 44pt",
      fixClasses: ["min-h-[44px]"],
    },
    { id: "scale-hero", nodeId: "hero", severity: "drift", message: "Type scale collapsed" },
  ];
  const conflict: IntentConflict = {
    nodeId: "cta",
    claim: "role",
    inferredValue: "primary-cta",
    suggestedValue: "secondary-cta",
    reason: "You demoted the primary CTA.",
  };

  it("reports a clean design when there is nothing to say", () => {
    render(
      <GuardChips
        violations={[]}
        conflict={null}
        onFix={() => {}}
        onSelectNode={() => {}}
        onRedefine={() => {}}
        onKeepIntent={() => {}}
      />,
    );
    expect(q("intent-guard").textContent).toContain("No contract breaks");
  });

  it("Fix button fires only for violations that carry a fix", () => {
    const onFix = vi.fn();
    render(
      <GuardChips
        violations={violations}
        conflict={null}
        onFix={onFix}
        onSelectNode={() => {}}
        onRedefine={() => {}}
        onKeepIntent={() => {}}
      />,
    );
    click("guard-fix-touch-cta");
    expect(onFix).toHaveBeenCalledWith(violations[0]);
    expect(container.querySelector('[data-testid="guard-fix-scale-hero"]')).toBeNull();
    expect(q("intent-guard").textContent).toContain("1 contract · 1 drift");
  });

  it("clicking a violation message selects its node", () => {
    const onSelectNode = vi.fn();
    render(
      <GuardChips
        violations={violations}
        conflict={null}
        onFix={() => {}}
        onSelectNode={onSelectNode}
        onRedefine={() => {}}
        onKeepIntent={() => {}}
      />,
    );
    act(() => {
      q("guard-chip-scale-hero")
        .querySelector("button")!
        .dispatchEvent(new window.MouseEvent("click", { bubbles: true }));
    });
    expect(onSelectNode).toHaveBeenCalledWith("hero");
  });

  it("conflict offers redefine vs keep-as-drift, both wired", () => {
    const onRedefine = vi.fn();
    const onKeepIntent = vi.fn();
    render(
      <GuardChips
        violations={[]}
        conflict={conflict}
        onFix={() => {}}
        onSelectNode={() => {}}
        onRedefine={onRedefine}
        onKeepIntent={onKeepIntent}
      />,
    );
    expect(q("intent-conflict").textContent).toContain("demoted");
    click("intent-redefine-chip");
    click("intent-keep-chip");
    expect(onRedefine).toHaveBeenCalledOnce();
    expect(onKeepIntent).toHaveBeenCalledOnce();
  });
});

describe("RipplePreview — rules, toggles and apply", () => {
  const rules: RippleRule[] = [
    { kind: "relative-delta", property: "radius", label: "+50% corner softness", confidence: 0.82, ratio: 1.5 },
    { kind: "literal", property: "radius", label: "set rounded-xl everywhere", confidence: 0.4, literal: "rounded-xl" },
  ];
  const proposals: RippleProposal[] = [
    { nodeId: "cta2", property: "radius", beforeToken: "rounded-md", afterToken: "rounded-lg", reason: "+50%" },
    { nodeId: "card", property: "radius", beforeToken: "rounded-sm", afterToken: "rounded-md", reason: "+50%" },
  ];

  const base = {
    rules,
    activeRuleIndex: 0,
    proposals,
    rejected: new Set<string>(),
    onSelectRule: vi.fn(),
    onToggleProposal: vi.fn(),
    onApply: vi.fn(),
    onDismiss: vi.fn(),
  };

  it("renders nothing when there is no inferred rule", () => {
    render(<RipplePreview {...base} rules={[]} />);
    expect(container.innerHTML).toBe("");
  });

  it("switching the inferred rule is clickable", () => {
    const onSelectRule = vi.fn();
    render(<RipplePreview {...base} onSelectRule={onSelectRule} />);
    click("ripple-rule-literal");
    expect(onSelectRule).toHaveBeenCalledWith(1);
  });

  it("toggling a proposal chip and applying works", () => {
    const onToggleProposal = vi.fn();
    const onApply = vi.fn();
    const onDismiss = vi.fn();
    render(
      <RipplePreview {...base} onToggleProposal={onToggleProposal} onApply={onApply} onDismiss={onDismiss} />,
    );
    expect(q("ripple-preview").textContent).toContain("2/2");
    click("ripple-item-cta2");
    click("ripple-apply");
    click("ripple-dismiss");
    expect(onToggleProposal).toHaveBeenCalledWith("cta2");
    expect(onApply).toHaveBeenCalledOnce();
    expect(onDismiss).toHaveBeenCalledOnce();
  });

  it("apply is disabled when every proposal is rejected", () => {
    render(<RipplePreview {...base} rejected={new Set(["cta2", "card"])} />);
    expect((q("ripple-apply") as HTMLButtonElement).disabled).toBe(true);
    expect(q("ripple-apply").textContent).toContain("(0)");
  });
});

describe("IntentTimelinePanel — restore, compare, branch", () => {
  const snapshot = seedIntent([{ id: "root", type: "box", children: [] }]);
  const entries: TimelineEntry[] = [
    {
      id: "t1",
      at: new Date().toISOString(),
      kind: "vision-import",
      source: "vision",
      summary: "Imported design",
      branch: "main",
      snapshot,
    },
    {
      id: "t2",
      at: new Date().toISOString(),
      kind: "intent-redefined",
      source: "user",
      summary: "cta → secondary",
      branch: "main",
      nodeId: "cta",
      snapshot,
    },
  ];

  it("renders nothing with an empty history", () => {
    render(
      <IntentTimelinePanel
        entries={[]}
        activeId={null}
        compareId={null}
        changedNodeIds={[]}
        onRestore={() => {}}
        onCompare={() => {}}
        onBranch={() => {}}
      />,
    );
    expect(container.innerHTML).toBe("");
  });

  it("each entry exposes working restore / compare / branch actions", () => {
    const onRestore = vi.fn();
    const onCompare = vi.fn();
    const onBranch = vi.fn();
    render(
      <IntentTimelinePanel
        entries={entries}
        activeId="t2"
        compareId={null}
        changedNodeIds={[]}
        onRestore={onRestore}
        onCompare={onCompare}
        onBranch={onBranch}
      />,
    );
    expect(q("intent-timeline").textContent).toContain("2 steps");
    click("timeline-restore-t1");
    click("timeline-compare-t1");
    click("timeline-branch-t1");
    expect(onRestore).toHaveBeenCalledWith("t1");
    expect(onCompare).toHaveBeenCalledWith("t1");
    expect(onBranch).toHaveBeenCalledWith("t1");
  });

  it("shows the diff line when comparing", () => {
    render(
      <IntentTimelinePanel
        entries={entries}
        activeId="t2"
        compareId="t1"
        changedNodeIds={["cta", "hero"]}
        onRestore={() => {}}
        onCompare={() => {}}
        onBranch={() => {}}
      />,
    );
    expect(q("timeline-diff").textContent).toContain("cta, hero");
  });

  it("shows 'identical' when nothing changed between snapshots", () => {
    render(
      <IntentTimelinePanel
        entries={entries}
        activeId="t2"
        compareId="t1"
        changedNodeIds={[]}
        onRestore={() => {}}
        onCompare={() => {}}
        onBranch={() => {}}
      />,
    );
    expect(q("timeline-diff").textContent).toContain("identical");
  });
});
