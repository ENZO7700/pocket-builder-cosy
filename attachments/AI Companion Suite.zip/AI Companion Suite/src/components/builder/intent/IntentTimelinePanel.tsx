import * as React from "react";
import type { TimelineEntry } from "@/lib/builder/intent";

const KIND_LABEL: Record<string, string> = {
  "vision-import": "Vision import",
  "property-edit": "Property edit",
  ripple: "Ripple",
  "guard-fix": "Guard fix",
  "intent-redefined": "Intent redefined",
  "intent-drift-kept": "Drift accepted",
  "scoped-ai-edit": "Scoped AI edit",
  "node-deleted": "Node deleted",
};

export interface IntentTimelinePanelProps {
  entries: TimelineEntry[];
  activeId: string | null;
  compareId: string | null;
  changedNodeIds: string[];
  onRestore: (id: string) => void;
  onCompare: (id: string) => void;
  onBranch: (id: string) => void;
}

export const IntentTimelinePanel: React.FC<IntentTimelinePanelProps> = ({
  entries,
  activeId,
  compareId,
  changedNodeIds,
  onRestore,
  onCompare,
  onBranch,
}) => {
  if (entries.length === 0) return null;

  return (
    <div
      data-testid="intent-timeline"
      className="rounded-xl border border-border-subtle bg-surface/60 p-4 space-y-3"
    >
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-medium">Intent timeline</h3>
        <span className="text-[11px] font-mono text-muted-foreground">{entries.length} steps</span>
      </div>

      <ol className="space-y-1.5 max-h-64 overflow-auto pr-1">
        {entries.map((entry) => {
          const isActive = entry.id === activeId;
          const isCompare = entry.id === compareId;
          return (
            <li
              key={entry.id}
              data-testid={`timeline-entry-${entry.id}`}
              className={`rounded-lg border px-3 py-2 text-xs transition-colors ${
                isActive
                  ? "border-accent-primary/40 bg-accent-primary/10"
                  : isCompare
                    ? "border-sky-500/40 bg-sky-500/10"
                    : "border-border-subtle bg-background/40"
              }`}
            >
              <div className="flex items-start justify-between gap-2">
                <div className="min-w-0">
                  <p className="text-[10px] uppercase tracking-wide text-muted-foreground">
                    {KIND_LABEL[entry.kind] ?? entry.kind} · {entry.source}
                    {entry.branch !== "main" ? ` · ${entry.branch}` : ""}
                  </p>
                  <p className="text-foreground break-words">{entry.summary}</p>
                </div>
                <div className="flex flex-col gap-1 shrink-0">
                  <button
                    type="button"
                    data-testid={`timeline-restore-${entry.id}`}
                    onClick={() => onRestore(entry.id)}
                    className="text-[10px] px-1.5 py-0.5 rounded border border-border hover:border-accent-primary/40 hover:text-accent-primary"
                  >
                    Restore
                  </button>
                  <button
                    type="button"
                    data-testid={`timeline-compare-${entry.id}`}
                    onClick={() => onCompare(entry.id)}
                    className="text-[10px] px-1.5 py-0.5 rounded border border-border hover:border-sky-400/40 hover:text-sky-300"
                  >
                    Compare
                  </button>
                  <button
                    type="button"
                    data-testid={`timeline-branch-${entry.id}`}
                    onClick={() => onBranch(entry.id)}
                    className="text-[10px] px-1.5 py-0.5 rounded border border-border hover:border-emerald-400/40 hover:text-emerald-300"
                  >
                    Branch
                  </button>
                </div>
              </div>
            </li>
          );
        })}
      </ol>

      {compareId && (
        <p data-testid="timeline-diff" className="text-[11px] font-mono text-muted-foreground">
          Diff vs {compareId}:{" "}
          {changedNodeIds.length === 0 ? "identical" : changedNodeIds.join(", ")}
        </p>
      )}
    </div>
  );
};
