import * as React from "react";
import type { RippleProposal, RippleRule } from "@/lib/builder/intent";

export interface RipplePreviewProps {
  rules: RippleRule[];
  activeRuleIndex: number;
  proposals: RippleProposal[];
  rejected: Set<string>;
  onSelectRule: (index: number) => void;
  onToggleProposal: (nodeId: string) => void;
  onApply: () => void;
  onDismiss: () => void;
}

export const RipplePreview: React.FC<RipplePreviewProps> = ({
  rules,
  activeRuleIndex,
  proposals,
  rejected,
  onSelectRule,
  onToggleProposal,
  onApply,
  onDismiss,
}) => {
  if (rules.length === 0) return null;
  const accepted = proposals.filter((p) => !rejected.has(p.nodeId));

  return (
    <div
      data-testid="ripple-preview"
      className="rounded-xl border border-indigo-500/30 bg-indigo-500/5 p-4 space-y-3"
    >
      <div className="flex items-center justify-between gap-2">
        <h3 className="text-sm font-medium">Ripple — propagate the decision</h3>
        <button
          type="button"
          data-testid="ripple-dismiss"
          onClick={onDismiss}
          className="text-[11px] text-muted-foreground hover:text-foreground"
        >
          Dismiss
        </button>
      </div>

      <div className="space-y-1.5">
        <p className="text-[10px] uppercase tracking-wide text-muted-foreground">
          Inferred rule (switch it)
        </p>
        <div className="flex flex-wrap gap-1.5">
          {rules.map((rule, index) => {
            const active = index === activeRuleIndex;
            return (
              <button
                key={`${rule.kind}-${index}`}
                type="button"
                data-testid={`ripple-rule-${rule.kind}`}
                onClick={() => onSelectRule(index)}
                className={`text-[11px] px-2.5 py-1 rounded-full border transition-colors ${
                  active
                    ? "bg-indigo-500/20 border-indigo-400/50 text-indigo-200 font-medium"
                    : "border-border text-muted-foreground hover:text-foreground"
                }`}
              >
                {rule.label}
                <span className="ml-1 opacity-60">{Math.round(rule.confidence * 100)}%</span>
              </button>
            );
          })}
        </div>
      </div>

      {proposals.length === 0 ? (
        <p className="text-xs text-muted-foreground">
          No related nodes need this change — the decision is already consistent.
        </p>
      ) : (
        <div className="space-y-1.5">
          <p className="text-[10px] uppercase tracking-wide text-muted-foreground">
            Affected nodes ({accepted.length}/{proposals.length})
          </p>
          <div className="flex flex-wrap gap-1.5">
            {proposals.map((proposal) => {
              const isRejected = rejected.has(proposal.nodeId);
              return (
                <button
                  key={proposal.nodeId}
                  type="button"
                  data-testid={`ripple-item-${proposal.nodeId}`}
                  onClick={() => onToggleProposal(proposal.nodeId)}
                  className={`text-[11px] px-2.5 py-1 rounded-full border font-mono transition-colors ${
                    isRejected
                      ? "border-border text-muted-foreground line-through opacity-60"
                      : "border-emerald-500/35 bg-emerald-500/10 text-emerald-200"
                  }`}
                >
                  {proposal.nodeId}: {proposal.beforeToken} → {proposal.afterToken}
                </button>
              );
            })}
          </div>
        </div>
      )}

      <button
        type="button"
        data-testid="ripple-apply"
        disabled={accepted.length === 0}
        onClick={onApply}
        className="px-3 py-1.5 rounded-lg text-xs font-medium bg-accent-primary/20 hover:bg-accent-primary/30 text-accent-primary border border-accent-primary/30 disabled:opacity-40"
      >
        Apply ripple ({accepted.length})
      </button>
    </div>
  );
};
