import * as React from "react";
import type { RawNode } from "@/lib/builder/semantic-intent/types";
import type { IntentClaim, IntentRole } from "@/lib/builder/intent";
import { INTENT_ROLES } from "@/lib/builder/intent";

const SOURCE_STYLE: Record<string, string> = {
  user: "bg-emerald-500/10 text-emerald-300 border-emerald-500/30",
  "project-rules": "bg-sky-500/10 text-sky-300 border-sky-500/30",
  vision: "bg-indigo-500/10 text-indigo-300 border-indigo-500/30",
};

function ClaimRow({ label, claim }: { label: string; claim?: IntentClaim<unknown> }) {
  if (!claim) return null;
  const value = Array.isArray(claim.value)
    ? claim.value.map((r) => (r as { kind: string; group: string }).group).join(", ") || "—"
    : String(claim.value);

  return (
    <div className="flex items-start justify-between gap-3 py-1.5 border-b border-border-subtle/50 last:border-0">
      <div className="min-w-0">
        <p className="text-[10px] uppercase tracking-wide text-muted-foreground">{label}</p>
        <p className="text-xs text-foreground break-words">{value}</p>
        {claim.overriddenBy && (
          <p className="text-[10px] text-amber-400/80 mt-0.5">
            overrode “{String(claim.overriddenBy.previousValue)}” · by {claim.overriddenBy.source}
          </p>
        )}
      </div>
      <div className="flex flex-col items-end gap-1 shrink-0">
        <span
          className={`text-[10px] px-1.5 py-0.5 rounded border font-mono ${SOURCE_STYLE[claim.source] ?? ""}`}
        >
          {claim.source}
        </span>
        <span className="text-[10px] text-muted-foreground font-mono">
          {Math.round(claim.confidence * 100)}%
        </span>
      </div>
    </div>
  );
}

export interface IntentPanelProps {
  node: RawNode | null;
  onRedefineRole: (nodeId: string, role: IntentRole) => void;
}

export const IntentPanel: React.FC<IntentPanelProps> = ({ node, onRedefineRole }) => {
  if (!node) {
    return (
      <div
        data-testid="intent-panel-empty"
        className="rounded-xl border border-border-subtle bg-surface/50 p-4 text-xs text-muted-foreground"
      >
        Select a node to see its canonical intent.
      </div>
    );
  }

  const intent = node.intent;

  return (
    <div
      data-testid="intent-panel"
      className="rounded-xl border border-border-subtle bg-surface/60 p-4 space-y-3"
    >
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-medium">Canonical intent</h3>
        <span className="text-[11px] font-mono text-muted-foreground truncate max-w-40">
          {node.id}
        </span>
      </div>

      {intent ? (
        <div>
          <ClaimRow label="Role" claim={intent.role} />
          <ClaimRow label="Rationale" claim={intent.rationale} />
          <ClaimRow label="Relations" claim={intent.relations} />
        </div>
      ) : (
        <p className="text-xs text-muted-foreground">No intent claims yet for this node.</p>
      )}

      <div className="space-y-1.5">
        <p className="text-[10px] uppercase tracking-wide text-muted-foreground">Redefine role</p>
        <div className="flex flex-wrap gap-1.5">
          {INTENT_ROLES.filter((r) => r !== "unknown").map((role) => {
            const active = intent?.role.value === role;
            return (
              <button
                key={role}
                type="button"
                data-testid={`intent-role-chip-${role}`}
                onClick={() => onRedefineRole(node.id, active ? "unknown" : role)}
                className={`text-[11px] px-2 py-1 rounded-full border transition-colors ${
                  active
                    ? "bg-accent-primary/20 border-accent-primary/40 text-accent-primary font-medium"
                    : "border-border text-muted-foreground hover:text-foreground hover:border-border-subtle"
                }`}
              >
                {role}
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
};
