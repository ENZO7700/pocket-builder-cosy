import * as React from "react";
import type { GuardViolation, IntentConflict } from "@/lib/builder/intent";

export interface GuardChipsProps {
  violations: GuardViolation[];
  conflict: IntentConflict | null;
  onFix: (violation: GuardViolation) => void;
  onSelectNode: (nodeId: string) => void;
  onRedefine: () => void;
  onKeepIntent: () => void;
}

export const GuardChips: React.FC<GuardChipsProps> = ({
  violations,
  conflict,
  onFix,
  onSelectNode,
  onRedefine,
  onKeepIntent,
}) => {
  const contracts = violations.filter((v) => v.severity === "contract");
  const drifts = violations.filter((v) => v.severity === "drift");

  return (
    <div
      data-testid="intent-guard"
      className="rounded-xl border border-border-subtle bg-surface/60 p-4 space-y-3"
    >
      <div className="flex items-center justify-between">
        <h3 className="text-sm font-medium">Intent Guard</h3>
        <span className="text-[11px] font-mono text-muted-foreground">
          {contracts.length} contract · {drifts.length} drift
        </span>
      </div>

      {conflict && (
        <div
          data-testid="intent-conflict"
          className="rounded-lg border border-amber-500/30 bg-amber-500/10 p-3 space-y-2"
        >
          <p className="text-xs text-amber-200">{conflict.reason}</p>
          <div className="flex flex-wrap gap-2">
            <button
              type="button"
              data-testid="intent-redefine-chip"
              onClick={onRedefine}
              className="text-[11px] px-2.5 py-1 rounded-full border border-emerald-500/40 bg-emerald-500/15 text-emerald-300 font-medium"
            >
              Redefine intent → {conflict.suggestedValue}
            </button>
            <button
              type="button"
              data-testid="intent-keep-chip"
              onClick={onKeepIntent}
              className="text-[11px] px-2.5 py-1 rounded-full border border-border text-muted-foreground hover:text-foreground"
            >
              Keep intent, treat as drift
            </button>
          </div>
        </div>
      )}

      {violations.length === 0 ? (
        <p className="text-xs text-muted-foreground">
          No contract breaks and no intent drift. The design matches its own reasoning.
        </p>
      ) : (
        <div className="flex flex-wrap gap-2">
          {violations.map((violation) => (
            <div
              key={violation.id}
              data-testid={`guard-chip-${violation.id}`}
              className={`flex items-center gap-2 text-[11px] px-2.5 py-1 rounded-full border ${
                violation.severity === "contract"
                  ? "border-rose-500/35 bg-rose-500/10 text-rose-200"
                  : "border-amber-500/30 bg-amber-500/10 text-amber-200"
              }`}
            >
              <button
                type="button"
                onClick={() => onSelectNode(violation.nodeId)}
                className="underline-offset-2 hover:underline text-left"
              >
                {violation.message}
              </button>
              {violation.fixClasses?.length ? (
                <button
                  type="button"
                  data-testid={`guard-fix-${violation.id}`}
                  onClick={() => onFix(violation)}
                  className="px-1.5 py-0.5 rounded bg-background/60 border border-border text-foreground font-medium"
                >
                  Fix
                </button>
              ) : null}
            </div>
          ))}
        </div>
      )}
    </div>
  );
};
