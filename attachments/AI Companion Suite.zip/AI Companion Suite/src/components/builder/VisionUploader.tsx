import * as React from "react";
import { UploadCloud, ImageIcon, Loader2 } from "lucide-react";
import { useTiltEffect } from "@/hooks/useTiltEffect";
import { useHaptic } from "@/hooks/useHaptic";

interface VisionUploaderProps {
  onImageProcess: (base64: string) => void;
  isProcessing: boolean;
}

export function VisionUploader({ onImageProcess, isProcessing }: VisionUploaderProps) {
  const [isDragging, setIsDragging] = React.useState(false);
  const [fileError, setFileError] = React.useState<string | null>(null);
  const tiltRef = useTiltEffect<HTMLDivElement>({ max: 5, scale: 1.02, speed: 400 });
  const inputRef = React.useRef<HTMLInputElement>(null);

  // Use our premium AMOLED PWA hooks
  const { triggerClick, triggerSuccess, triggerError } = useHaptic();

  const handleDragOver = React.useCallback(
    (e: React.DragEvent) => {
      e.preventDefault();
      if (!isDragging) {
        setIsDragging(true);
        triggerClick();
      }
    },
    [isDragging, triggerClick],
  );

  const handleDragLeave = React.useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setIsDragging(false);
  }, []);

  const processFile = React.useCallback(
    (file: File) => {
      if (!file.type.startsWith("image/")) {
        triggerError();
        setFileError("Unsupported file. Please choose a PNG, JPG or WebP image.");
        return;
      }

      // We got an image, vibrate success and process
      setFileError(null);
      triggerSuccess();
      const reader = new FileReader();
      reader.onerror = () => {
        triggerError();
        setFileError("Could not read that file. Try another image.");
      };
      reader.onload = (e) => {
        const result = e.target?.result as string;
        if (result) {
          onImageProcess(result);
        }
      };
      reader.readAsDataURL(file);
    },
    [onImageProcess, triggerError, triggerSuccess],
  );

  const handleDrop = React.useCallback(
    (e: React.DragEvent) => {
      e.preventDefault();
      setIsDragging(false);

      if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
        processFile(e.dataTransfer.files[0]);
      }
    },
    [processFile],
  );

  const handleFileInput = React.useCallback(
    (e: React.ChangeEvent<HTMLInputElement>) => {
      const file = e.target.files?.[0];
      // Allow re-selecting the same file later
      e.target.value = "";
      if (file) processFile(file);
    },
    [processFile],
  );

  const handleKeyDown = React.useCallback((e: React.KeyboardEvent) => {
    if (e.key === "Enter" || e.key === " ") {
      e.preventDefault();
      inputRef.current?.click();
    }
  }, []);

  return (
    <div className="w-full max-w-xl mx-auto">
      <label
        role="button"
        tabIndex={isProcessing ? -1 : 0}
        onKeyDown={handleKeyDown}
        onDragOver={handleDragOver}
        onDragLeave={handleDragLeave}
        onDrop={handleDrop}
        className="block outline-none focus-visible:ring-2 focus-visible:ring-accent-primary focus-visible:ring-offset-2 focus-visible:ring-offset-background rounded-3xl"
      >
        <input
          ref={inputRef}
          type="file"
          accept="image/*"
          onChange={handleFileInput}
          className="sr-only"
          aria-label="Upload screenshot"
          disabled={isProcessing}
        />

        <div
          ref={tiltRef}
          className={`
            relative overflow-hidden rounded-3xl border-2 border-dashed
            transition-all duration-300 ease-out flex flex-col items-center justify-center
            min-h-[300px] p-8 text-center cursor-pointer
            ${
              isDragging
                ? "border-accent-primary bg-accent-primary/10 glow-accent scale-[1.02]"
                : "border-border-subtle bg-surface hover:border-accent-primary/50"
            }
            ${isProcessing ? "opacity-70 pointer-events-none" : ""}
          `}
        >
          {/* Glow effect matching AMOLED theme */}
          <div className="absolute inset-0 bg-mesh-glow opacity-30 pointer-events-none" />

          <div className="relative z-20 flex flex-col items-center gap-4 pointer-events-none">
            <div
              className={`p-4 rounded-full glass transition-transform duration-500 ${isDragging ? "scale-110" : ""}`}
            >
              {isProcessing ? (
                <Loader2 className="w-10 h-10 text-accent-primary animate-spin" />
              ) : isDragging ? (
                <UploadCloud className="w-10 h-10 text-accent-primary animate-bounce" />
              ) : (
                <ImageIcon className="w-10 h-10 text-muted-foreground" />
              )}
            </div>

            <div className="space-y-2">
              <h3 className="text-xl font-semibold tracking-tight text-foreground">
                {isProcessing ? "Analyzing pixels..." : "Drag & Drop a screenshot"}
              </h3>
              <p className="text-sm text-muted-foreground max-w-[250px] mx-auto">
                {isProcessing
                  ? "Our Semantic Intent Engine is detecting interactive elements."
                  : "Or click to select. We'll turn your design into interactive React components."}
              </p>
            </div>
          </div>
        </div>
      </label>

      {fileError && (
        <p role="alert" className="mt-3 text-sm text-destructive text-center">
          {fileError}
        </p>
      )}
    </div>
  );
}

