import { createStart, createMiddleware, createCsrfMiddleware } from "@tanstack/react-start";

import { renderErrorPage } from "./lib/error-page";
// Replaces generated `attachSupabaseAuth`: this project has no login gate, so the
// bearer token may need the shared workspace session to be opened first.
import { attachWorkspaceAuth } from "@/lib/session-attacher";
import { describeAuthHeader, log, startSpan, traceFromHeaders } from "@/lib/observability/trace";

const csrfMiddleware = createCsrfMiddleware({
  filter: (ctx) => ctx.handlerType === "serverFn",
});

/**
 * One span per server request (SSR, server routes, server functions) carrying
 * the browser trace id, so an "Unauthorized" thrown deep inside a server
 * function can be correlated with the client attach step that produced it.
 */
const tracingMiddleware = createMiddleware().server(async ({ next, request }) => {
  const ctx = traceFromHeaders(request?.headers);
  const url = request ? new URL(request.url) : null;
  const span = startSpan("http.request", ctx, {
    method: request?.method,
    path: url?.pathname,
    ...describeAuthHeader(request?.headers?.get("authorization")),
  });
  try {
    const result = await next();
    span.end();
    return result;
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    span.fail(error, {
      unauthorized: /unauthorized/i.test(message),
    });
    throw error;
  }
});

const errorMiddleware = createMiddleware().server(async ({ next }) => {
  try {
    return await next();
  } catch (error) {
    if (error != null && typeof error === "object" && "statusCode" in error) {
      throw error;
    }
    log("error", "http.unhandled_error", {
      errorMessage: error instanceof Error ? error.message : String(error),
    });
    return new Response(renderErrorPage(), {
      status: 500,
      headers: { "content-type": "text/html; charset=utf-8" },
    });
  }
});

export const startInstance = createStart(() => ({
  functionMiddleware: [attachWorkspaceAuth],
  requestMiddleware: [tracingMiddleware, csrfMiddleware, errorMiddleware],
}));

