import { createServerFn } from "@tanstack/react-start";

/**
 * No login, no gate: hand every visitor the shared workspace session so all
 * RLS-scoped data keeps working. There is no password and no auth screen.
 *
 * Never throws: when the hosted backend is unreachable (paused, cold start,
 * network blip) we return `session: null` so the app still renders instead of
 * blanking the screen on a server-function error.
 */
export const openWorkspaceSession = createServerFn({ method: "POST" }).handler(async () => {
  const { startSpan } = await import("./observability/trace");
  const span = startSpan("workspace.session.open", undefined);
  try {
    const { createSharedSession } = await import("./gate.server");
    const session = await createSharedSession();
    span.end({ hasSession: Boolean(session) });
    return { session, error: null as string | null };
  } catch (e) {
    const message = e instanceof Error ? e.message : "Workspace session unavailable";
    span.fail(e, { phase: "createSharedSession" });
    return { session: null, error: message };
  }
});
