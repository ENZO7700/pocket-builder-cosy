/**
 * Ship gate: Mistral-only policy.
 * Guards against a regression where an OpenAI / Gemini model id leaks back into
 * runtime code paths or migration column defaults.
 */
import { readFileSync, readdirSync, statSync } from "node:fs";
import { join } from "node:path";
import { describe, expect, it } from "vitest";
import { DEFAULT_MODEL, isMistralModelId, resolveKnownModelId } from "@/lib/models";

const FOREIGN_MODEL = /\b(openai\/gpt|google\/gemini|anthropic\/claude)[\w.-]*/;

function walk(dir: string, out: string[] = []): string[] {
  for (const entry of readdirSync(dir)) {
    const full = join(dir, entry);
    if (statSync(full).isDirectory()) {
      if (entry === "node_modules" || entry === "dist") continue;
      walk(full, out);
      continue;
    }
    if (/\.(ts|tsx)$/.test(entry) && !/\.test\.(ts|tsx)$/.test(entry)) out.push(full);
  }
  return out;
}

describe("model policy", () => {
  it("maps legacy gateway ids to the Mistral default", () => {
    expect(resolveKnownModelId("openai/gpt-5.5")).toBe(DEFAULT_MODEL);
    expect(resolveKnownModelId("google/gemini-3.7-flash")).toBe(DEFAULT_MODEL);
    expect(resolveKnownModelId(null)).toBe(DEFAULT_MODEL);
    expect(isMistralModelId(DEFAULT_MODEL)).toBe(true);
  });

  it("has no foreign model id in runtime source", () => {
    const offenders: string[] = [];
    for (const file of walk("src")) {
      if (file.includes("routeTree.gen")) continue;
      const src = readFileSync(file, "utf8");
      if (FOREIGN_MODEL.test(src)) offenders.push(file);
    }
    expect(offenders).toEqual([]);
  });

  it("database defaults were migrated to Mistral", () => {
    const dir = "supabase/migrations";
    const latest = readdirSync(dir)
      .filter((f) => f.endsWith(".sql"))
      .sort()
      .map((f) => readFileSync(join(dir, f), "utf8"))
      .join("\n");
    expect(latest).toMatch(/ALTER COLUMN model SET DEFAULT 'mistral-large-latest'/);
    expect(latest).toMatch(/ALTER COLUMN default_model SET DEFAULT 'mistral-large-latest'/);
  });
});
