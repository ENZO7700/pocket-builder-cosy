import { describe, expect, it, vi } from "vitest";
import {
  describeAuthHeader,
  fingerprint,
  newTraceId,
  redactFields,
  startSpan,
  traceFromHeaders,
  traceHeaders,
} from "./trace";

function jwt(payload: Record<string, unknown>): string {
  const b64 = (o: unknown) => btoa(JSON.stringify(o)).replace(/=+$/, "");
  return `${b64({ alg: "HS256" })}.${b64(payload)}.sig`;
}

describe("trace", () => {
  it("generates unique hex trace ids", () => {
    const a = newTraceId();
    expect(a).toMatch(/^[0-9a-f]{32}$/);
    expect(a).not.toBe(newTraceId());
  });

  it("never logs raw secrets", () => {
    const out = redactFields({ Authorization: "Bearer supersecret", token: "abc", path: "/chat" });
    expect(JSON.stringify(out)).not.toContain("supersecret");
    expect(out["path"]).toBe("/chat");
    expect(String(out["token"])).toMatch(/^redacted:/);
  });

  it("describes a missing header as the unauthorized reason", () => {
    expect(describeAuthHeader(null)).toMatchObject({
      authPresent: false,
      authReason: "missing-header",
    });
    expect(describeAuthHeader("Basic x")).toMatchObject({ authReason: "wrong-scheme" });
  });

  it("reports jwt expiry without leaking the token", () => {
    const token = jwt({ exp: Math.floor(Date.now() / 1000) - 10, sub: "user-1" });
    const info = describeAuthHeader(`Bearer ${token}`);
    expect(info["tokenExpired"]).toBe(true);
    expect(info["tokenParts"]).toBe(3);
    expect(JSON.stringify(info)).not.toContain(token);
  });

  it("propagates trace ids across hops", () => {
    const ctx = traceFromHeaders(new Headers({ "x-trace-id": "abc123def456" }));
    expect(ctx.traceId).toBe("abc123def456");
    expect(traceHeaders(ctx)["x-trace-id"]).toBe("abc123def456");
  });

  it("emits structured start/end lines for a span", () => {
    const info = vi.spyOn(console, "log").mockImplementation(() => {});
    const span = startSpan("chat.api", { traceId: "t1" });
    span.end({ httpStatus: 200 });
    const lines = info.mock.calls.map((c) => JSON.parse(String(c[0])));
    expect(lines[0]).toMatchObject({ event: "span.start", span: "chat.api", traceId: "t1" });
    expect(lines[1]).toMatchObject({ event: "span.end", status: "ok", httpStatus: 200 });
    info.mockRestore();
  });

  it("fingerprints deterministically", () => {
    expect(fingerprint("a")).toBe(fingerprint("a"));
    expect(fingerprint("a")).not.toBe(fingerprint("b"));
  });
});
