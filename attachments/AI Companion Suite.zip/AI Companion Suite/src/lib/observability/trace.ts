/**
 * Structured logging + lightweight tracing for the whole /chat flow.
 *
 * Isomorphic (browser + Cloudflare Worker): no node built-ins, no async_hooks.
 * Trace context is propagated explicitly through the `x-trace-id` /
 * `x-span-id` headers so a browser click, the server functions it triggers and
 * the streaming /api/chat request all share one trace id.
 *
 * Never log tokens, keys or message content — use `describeAuthHeader` /
 * `fingerprint` for correlatable but non-sensitive values.
 */

export const TRACE_HEADER = "x-trace-id";
export const SPAN_HEADER = "x-span-id";

export type LogLevel = "debug" | "info" | "warn" | "error";

export type TraceContext = {
  traceId: string;
  spanId?: string | undefined;
};

export type LogFields = Record<string, unknown>;

const HEX = "0123456789abcdef";

function randomHex(length: number): string {
  const bytes = new Uint8Array(length / 2);
  const cryptoObj = globalThis.crypto;
  if (cryptoObj?.getRandomValues) {
    cryptoObj.getRandomValues(bytes);
  } else {
    for (let i = 0; i < bytes.length; i += 1) bytes[i] = Math.floor(Math.random() * 256);
  }
  let out = "";
  for (const b of bytes) out += HEX[(b >> 4) & 0xf]! + HEX[b & 0xf]!;
  return out;
}

export function newTraceId(): string {
  return randomHex(32);
}

export function newSpanId(): string {
  return randomHex(16);
}

/** Stable, non-reversible short fingerprint used to correlate tokens/ids in logs. */
export function fingerprint(value: string | null | undefined): string {
  if (!value) return "none";
  let h1 = 0x811c9dc5;
  let h2 = 0x01000193;
  for (let i = 0; i < value.length; i += 1) {
    const c = value.charCodeAt(i);
    h1 = Math.imul(h1 ^ c, 0x01000193) >>> 0;
    h2 = Math.imul(h2 + c, 0x85ebca6b) >>> 0;
  }
  return (h1.toString(16) + h2.toString(16)).slice(0, 12);
}

const SENSITIVE_KEY = /(token|secret|key|password|authorization|cookie|apikey)/i;

/** Drop/redact anything sensitive before it reaches the log sink. */
export function redactFields(fields: LogFields): LogFields {
  const out: LogFields = {};
  for (const [key, value] of Object.entries(fields)) {
    if (value === undefined) continue;
    if (SENSITIVE_KEY.test(key)) {
      out[key] = typeof value === "string" ? `redacted:${fingerprint(value)}` : "redacted";
      continue;
    }
    out[key] = value instanceof Error ? { name: value.name, message: value.message } : value;
  }
  return out;
}

/** Non-sensitive description of an Authorization header — the core Unauthorized clue. */
export function describeAuthHeader(header: string | null | undefined): LogFields {
  if (!header) return { authPresent: false, authReason: "missing-header" };
  if (!header.startsWith("Bearer ")) {
    return { authPresent: true, authReason: "wrong-scheme", authScheme: header.split(" ")[0] };
  }
  const token = header.slice("Bearer ".length).trim();
  if (!token) return { authPresent: true, authReason: "empty-token" };
  const parts = token.split(".");
  const info: LogFields = {
    authPresent: true,
    authScheme: "Bearer",
    tokenParts: parts.length,
    tokenFp: fingerprint(token),
  };
  if (parts.length !== 3) {
    info["authReason"] = "not-a-jwt";
    return info;
  }
  try {
    const json = JSON.parse(
      atob(parts[1]!.replace(/-/g, "+").replace(/_/g, "/").padEnd(parts[1]!.length + ((4 - (parts[1]!.length % 4)) % 4), "=")),
    ) as { exp?: number; sub?: string; role?: string };
    if (typeof json.exp === "number") {
      const secondsLeft = Math.round(json.exp - Date.now() / 1000);
      info["tokenExpiresInSec"] = secondsLeft;
      info["tokenExpired"] = secondsLeft <= 0;
    }
    if (json.sub) info["userFp"] = fingerprint(json.sub);
    if (json.role) info["tokenRole"] = json.role;
  } catch {
    info["authReason"] = "unparsable-claims";
  }
  return info;
}

export function traceFromHeaders(headers: Headers | null | undefined): TraceContext {
  const traceId = headers?.get(TRACE_HEADER)?.trim();
  const spanId = headers?.get(SPAN_HEADER)?.trim();
  return {
    traceId: traceId && /^[a-z0-9-]{8,64}$/i.test(traceId) ? traceId : newTraceId(),
    spanId: spanId && /^[a-z0-9-]{4,64}$/i.test(spanId) ? spanId : undefined,
  };
}

export function traceHeaders(ctx: TraceContext): Record<string, string> {
  return ctx.spanId
    ? { [TRACE_HEADER]: ctx.traceId, [SPAN_HEADER]: ctx.spanId }
    : { [TRACE_HEADER]: ctx.traceId };
}

const runtime = typeof window === "undefined" ? "server" : "browser";

export function log(level: LogLevel, event: string, fields: LogFields = {}): void {
  const entry = {
    ts: new Date().toISOString(),
    level,
    event,
    runtime,
    ...redactFields(fields),
  };
  const line = JSON.stringify(entry);
  if (level === "error") console.error(line);
  else if (level === "warn") console.warn(line);
  else console.log(line);
}

export type Span = {
  traceId: string;
  spanId: string;
  name: string;
  /** Headers to forward so the next hop joins this trace. */
  headers(): Record<string, string>;
  child(name: string, fields?: LogFields): Span;
  event(name: string, fields?: LogFields): void;
  end(fields?: LogFields): number;
  fail(error: unknown, fields?: LogFields): number;
};

export function startSpan(
  name: string,
  parent: TraceContext | Span | undefined,
  fields: LogFields = {},
): Span {
  const traceId = parent?.traceId ?? newTraceId();
  const parentSpanId = parent && "spanId" in parent ? parent.spanId : undefined;
  const spanId = newSpanId();
  const startedAt = Date.now();
  const base = { traceId, spanId, parentSpanId, span: name };

  log("info", "span.start", { ...base, ...fields });

  const span: Span = {
    traceId,
    spanId,
    name,
    headers: () => traceHeaders({ traceId, spanId }),
    child: (childName, childFields) =>
      startSpan(childName, { traceId, spanId }, childFields ?? {}),
    event: (eventName, eventFields) =>
      log("info", eventName, { ...base, ...(eventFields ?? {}) }),
    end: (endFields) => {
      const durationMs = Date.now() - startedAt;
      log("info", "span.end", { ...base, status: "ok", durationMs, ...(endFields ?? {}) });
      return durationMs;
    },
    fail: (error, failFields) => {
      const durationMs = Date.now() - startedAt;
      const message = error instanceof Error ? error.message : String(error);
      log("error", "span.end", {
        ...base,
        status: "error",
        durationMs,
        errorName: error instanceof Error ? error.name : typeof error,
        errorMessage: message.slice(0, 500),
        ...(failFields ?? {}),
      });
      return durationMs;
    },
  };
  return span;
}

/** Browser-side trace id shared by session bootstrap + server-fn calls of one page. */
let browserTraceId: string | null = null;
export function currentBrowserTrace(): TraceContext {
  browserTraceId ??= newTraceId();
  return { traceId: browserTraceId };
}
export function resetBrowserTraceForTests(): void {
  browserTraceId = null;
}
