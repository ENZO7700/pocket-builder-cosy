import { createMiddleware } from "@tanstack/react-start";
import { ensureWorkspaceAccessToken } from "@/lib/workspace-session";
import { currentBrowserTrace, describeAuthHeader, log, newSpanId } from "@/lib/observability/trace";

/**
 * Attaches the Supabase bearer token to every server-function call, opening the
 * shared workspace session first when the browser has none yet (no login gate).
 *
 * Every call is logged with the page trace id so a production "Unauthorized"
 * can be traced from the browser attach step to the server middleware.
 */
export const attachWorkspaceAuth = createMiddleware({ type: "function" }).client(
  async ({ next }) => {
    let token: string | null = null;
    const { traceId } = currentBrowserTrace();
    const spanId = newSpanId();

    if (typeof window !== "undefined") {
      try {
        token = await ensureWorkspaceAccessToken();
      } catch (e) {
        log("error", "serverfn.auth.attach_failed", {
          traceId,
          spanId,
          errorMessage: e instanceof Error ? e.message : String(e),
        });
      }
    }

    const authHeader = token ? `Bearer ${token}` : null;
    log(token ? "info" : "warn", "serverfn.auth.attach", {
      traceId,
      spanId,
      ...describeAuthHeader(authHeader),
    });

    const headers: Record<string, string> = { "x-trace-id": traceId, "x-span-id": spanId };
    if (authHeader) headers["Authorization"] = authHeader;
    return next({ headers });
  },
);
