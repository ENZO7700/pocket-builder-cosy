// Server-only helpers for the shared one-time password gate.
// There are no user accounts: everyone who knows the access code shares
// a single backing workspace account so all existing RLS-scoped data works.
import { createClient } from "@supabase/supabase-js";
import { createHash, timingSafeEqual } from "node:crypto";
import type { Database } from "@/integrations/supabase/types";
import { supabaseAdmin } from "@/integrations/supabase/client.server";

export const SHARED_ACCOUNT_EMAIL = "workspace@cosy.app";

/** Constant-time compare of two arbitrary-length strings. */
export function passwordMatches(input: string, expected: string): boolean {
  const a = createHash("sha256").update(input, "utf8").digest();
  const b = createHash("sha256").update(expected, "utf8").digest();
  return timingSafeEqual(a, b);
}

function publishableClient() {
  const url = process.env.SUPABASE_URL;
  const key = process.env.SUPABASE_PUBLISHABLE_KEY;
  if (!url || !key) throw new Error("Workspace backend configuration is unavailable");
  return createClient<Database>(url, key, {
    auth: { storage: undefined, persistSession: false, autoRefreshToken: false },
    global: {
      fetch: (input, init) => {
        const h = new Headers(init?.headers);
        if (key.startsWith("sb_") && h.get("Authorization") === `Bearer ${key}`) {
          h.delete("Authorization");
        }
        h.set("apikey", key);
        return fetch(input, { ...init, headers: h });
      },
    },
  });
}

/** Ensure the single shared workspace account exists, then return a session for it. */
export async function createSharedSession() {
  const accountPassword = process.env.SHARED_ACCOUNT_PASSWORD;
  if (!accountPassword) throw new Error("SHARED_ACCOUNT_PASSWORD is not configured");

  const client = publishableClient();
  let signIn = await client.auth.signInWithPassword({
    email: SHARED_ACCOUNT_EMAIL,
    password: accountPassword,
  });

  if (signIn.error) {
    // First run (or rotated password): provision / repair the shared account.
    const { data: list, error: listError } = await supabaseAdmin.auth.admin.listUsers({
      page: 1,
      perPage: 200,
    });
    if (listError) throw new Error(`Workspace account lookup failed: ${listError.message}`);
    const existing = list?.users.find((u) => u.email === SHARED_ACCOUNT_EMAIL);
    if (existing) {
      const { error } = await supabaseAdmin.auth.admin.updateUserById(existing.id, {
        password: accountPassword,
        email_confirm: true,
      });
      if (error) throw new Error(`Workspace account repair failed: ${error.message}`);
    } else {
      const { error } = await supabaseAdmin.auth.admin.createUser({
        email: SHARED_ACCOUNT_EMAIL,
        password: accountPassword,
        email_confirm: true,
      });
      if (error) throw new Error(error.message);
    }
    signIn = await client.auth.signInWithPassword({
      email: SHARED_ACCOUNT_EMAIL,
      password: accountPassword,
    });
  }

  if (signIn.error || !signIn.data.session) {
    throw new Error(signIn.error?.message ?? "Could not open the workspace session");
  }

  return {
    access_token: signIn.data.session.access_token,
    refresh_token: signIn.data.session.refresh_token,
  };
}
