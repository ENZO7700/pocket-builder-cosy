import type { RawNode } from "../semantic-intent/types";
import { flatten, mapNodes, findNode } from "./canonicalIntent";
import { applyRuleToToken, diffNode, readToken, writeToken } from "./ruleInference";
import type { EditDelta, RippleProposal, RippleRule } from "./types";

/**
 * Nodes related to the edited node through the canonical intent layer.
 * Relations beat DOM proximity: a CTA in the footer is still a CTA.
 */
export function relatedNodes(ast: RawNode[], targetId: string): RawNode[] {
  const target = findNode(ast, targetId);
  if (!target) return [];

  const groups = new Set((target.intent?.relations.value ?? []).map((r) => r.group));
  const role = target.intent?.role.value;

  return flatten(ast).filter((node) => {
    if (node.id === targetId) return false;
    const nodeGroups = (node.intent?.relations.value ?? []).map((r) => r.group);
    if (nodeGroups.some((g) => groups.has(g))) return true;
    return Boolean(role && role !== "unknown" && node.intent?.role.value === role);
  });
}

/** Build ripple proposals by applying a design rule, not a raw value. */
export function computeRipple(
  ast: RawNode[],
  delta: EditDelta,
  rule: RippleRule,
): RippleProposal[] {
  const proposals: RippleProposal[] = [];

  for (const node of relatedNodes(ast, delta.nodeId)) {
    const currentToken = readToken(node, rule.property);
    if (!currentToken) continue;
    const next = applyRuleToToken(rule, currentToken);
    if (!next) continue;
    proposals.push({
      nodeId: node.id,
      property: rule.property,
      beforeToken: currentToken,
      afterToken: next,
      reason: rule.label,
    });
  }

  return proposals;
}

/** Apply accepted proposals as one atomic AST transform (single undo step). */
export function applyRipple(ast: RawNode[], proposals: RippleProposal[]): RawNode[] {
  if (proposals.length === 0) return ast;
  const byId = new Map(proposals.map((p) => [p.nodeId, p]));
  return mapNodes(ast, (node) => {
    const proposal = byId.get(node.id);
    if (!proposal) return node;
    return writeToken(node, proposal.property, proposal.afterToken);
  });
}

/** Convenience: detect the edit and return the ranked rules for it. */
export function detectEdit(before: RawNode, after: RawNode): EditDelta | null {
  return diffNode(before, after);
}
