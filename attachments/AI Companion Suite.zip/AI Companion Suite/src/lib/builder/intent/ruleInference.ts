import type { RawNode } from "../semantic-intent/types";
import type { EditDelta, EditProperty, RippleRule } from "./types";

/* ------------------------------------------------------------------ */
/* Tailwind token scales                                               */
/* ------------------------------------------------------------------ */

export const RADIUS_SCALE: Array<{ token: string; value: number }> = [
  { token: "rounded-none", value: 0 },
  { token: "rounded-sm", value: 2 },
  { token: "rounded", value: 4 },
  { token: "rounded-md", value: 6 },
  { token: "rounded-lg", value: 8 },
  { token: "rounded-xl", value: 12 },
  { token: "rounded-2xl", value: 16 },
  { token: "rounded-3xl", value: 24 },
  { token: "rounded-full", value: 9999 },
];

export const PADDING_SCALE: Array<{ token: string; value: number }> = [
  { token: "p-0", value: 0 },
  { token: "p-1", value: 4 },
  { token: "p-2", value: 8 },
  { token: "p-3", value: 12 },
  { token: "p-4", value: 16 },
  { token: "p-6", value: 24 },
  { token: "p-8", value: 32 },
  { token: "p-10", value: 40 },
  { token: "p-12", value: 48 },
];

export const FONT_SCALE: Array<{ token: string; value: number }> = [
  { token: "text-xs", value: 12 },
  { token: "text-sm", value: 14 },
  { token: "text-base", value: 16 },
  { token: "text-lg", value: 18 },
  { token: "text-xl", value: 20 },
  { token: "text-2xl", value: 24 },
  { token: "text-3xl", value: 30 },
  { token: "text-4xl", value: 36 },
  { token: "text-5xl", value: 48 },
  { token: "text-6xl", value: 60 },
  { token: "text-7xl", value: 72 },
];

export const COLOR_ROLE_TOKENS = [
  "bg-transparent",
  "bg-white",
  "bg-slate-900",
  "bg-indigo-600",
  "bg-emerald-600",
  "bg-rose-600",
];

/** Density bands used by the token-switch rule. */
export const DENSITY_BANDS: Array<{ token: string; max: number }> = [
  { token: "compact", max: 8 },
  { token: "cozy", max: 16 },
  { token: "comfortable", max: 9999 },
];

export function scaleFor(property: EditProperty) {
  switch (property) {
    case "radius":
      return RADIUS_SCALE;
    case "padding":
      return PADDING_SCALE;
    case "fontSize":
      return FONT_SCALE;
    default:
      return [];
  }
}

export function tokenIndex(property: EditProperty, token: string): number {
  return scaleFor(property).findIndex((s) => s.token === token);
}

export function tokenValue(property: EditProperty, token: string): number | null {
  const found = scaleFor(property).find((s) => s.token === token);
  return found ? found.value : null;
}

export function nearestToken(property: EditProperty, value: number): string {
  const scale = scaleFor(property);
  let best = scale[0]!;
  for (const entry of scale) {
    if (Math.abs(entry.value - value) < Math.abs(best.value - value)) best = entry;
  }
  return best.token;
}

export function densityOf(property: EditProperty, token: string): string | null {
  const value = tokenValue(property, token);
  if (value === null) return null;
  return DENSITY_BANDS.find((band) => value <= band.max)!.token;
}

/* ------------------------------------------------------------------ */
/* Reading tokens off a node                                           */
/* ------------------------------------------------------------------ */

const MATCHERS: Record<EditProperty, RegExp> = {
  radius: /^rounded(-(none|sm|md|lg|xl|2xl|3xl|full))?$/,
  padding: /^p-\d+$/,
  fontSize: /^text-(xs|sm|base|lg|xl|2xl|3xl|4xl|5xl|6xl|7xl)$/,
  colorRole: /^bg-[a-z]+(-\d{2,3})?$/,
};

export function readToken(node: RawNode, property: EditProperty): string | null {
  const tokens = (node.className ?? "").split(/\s+/).filter(Boolean);
  return tokens.find((t) => MATCHERS[property].test(t)) ?? null;
}

export function writeToken(node: RawNode, property: EditProperty, token: string): RawNode {
  const tokens = (node.className ?? "").split(/\s+/).filter(Boolean);
  const kept = tokens.filter((t) => !MATCHERS[property].test(t));
  kept.push(token);
  return { ...node, className: kept.join(" ") };
}

/** Diff two versions of a node into a single property delta, if any. */
export function diffNode(before: RawNode, after: RawNode): EditDelta | null {
  const properties: EditProperty[] = ["radius", "padding", "fontSize", "colorRole"];
  for (const property of properties) {
    const b = readToken(before, property);
    const a = readToken(after, property);
    if (a && b && a !== b) {
      return { nodeId: after.id, property, beforeToken: b, afterToken: a };
    }
  }
  return null;
}

/* ------------------------------------------------------------------ */
/* Rule inference — the design decision behind the edit                */
/* ------------------------------------------------------------------ */

function pct(ratio: number): string {
  const delta = Math.round((ratio - 1) * 100);
  return `${delta > 0 ? "+" : ""}${delta}%`;
}

const PROPERTY_LABEL: Record<EditProperty, string> = {
  radius: "corner softness",
  padding: "spacing density",
  fontSize: "type size",
  colorRole: "colour role",
};

/**
 * Infer the transformation rules that could explain an edit, ranked by
 * confidence. A ripple propagates the highest-confidence rule, never the
 * raw value — unless the user picks the literal chip.
 */
export function inferRules(delta: EditDelta): RippleRule[] {
  const { property, beforeToken, afterToken } = delta;
  const rules: RippleRule[] = [];

  if (property === "colorRole") {
    rules.push({
      kind: "semantic-swap",
      property,
      label: `colour role → ${afterToken.replace("bg-", "")}`,
      confidence: 0.9,
      token: afterToken,
    });
    rules.push({
      kind: "literal",
      property,
      label: `set ${afterToken}`,
      confidence: 0.4,
      literal: afterToken,
    });
    return rules.sort((a, b) => b.confidence - a.confidence);
  }

  const beforeValue = tokenValue(property, beforeToken);
  const afterValue = tokenValue(property, afterToken);
  const beforeIdx = tokenIndex(property, beforeToken);
  const afterIdx = tokenIndex(property, afterToken);

  if (beforeIdx >= 0 && afterIdx >= 0 && beforeIdx !== afterIdx) {
    const steps = afterIdx - beforeIdx;
    rules.push({
      kind: "scale-step",
      property,
      label: `${steps > 0 ? "+" : ""}${steps} step${Math.abs(steps) === 1 ? "" : "s"} on the ${property === "fontSize" ? "type" : property} scale`,
      // Type scale thinking is step-based; geometry is ratio-based.
      confidence: property === "fontSize" ? 0.88 : 0.6,
      steps,
    });
  }

  if (beforeValue !== null && afterValue !== null && beforeValue > 0 && afterValue !== beforeValue) {
    const ratio = afterValue / beforeValue;
    if (Number.isFinite(ratio) && ratio > 0 && ratio < 20) {
      rules.push({
        kind: "relative-delta",
        property,
        label: `${pct(ratio)} ${PROPERTY_LABEL[property]}`,
        confidence: property === "fontSize" ? 0.6 : 0.82,
        ratio,
      });
    }
  }

  if (property === "padding") {
    const beforeBand = densityOf(property, beforeToken);
    const afterBand = densityOf(property, afterToken);
    if (beforeBand && afterBand && beforeBand !== afterBand) {
      rules.push({
        kind: "token-switch",
        property,
        label: `spacing density ${beforeBand} → ${afterBand}`,
        confidence: 0.86,
        token: afterBand,
      });
    }
  }

  rules.push({
    kind: "literal",
    property,
    label: `set ${afterToken} everywhere`,
    confidence: 0.4,
    literal: afterToken,
  });

  return rules.sort((a, b) => b.confidence - a.confidence);
}

/**
 * Apply a rule to another node **in that node's own terms**.
 * Returns the new token, or null when the rule is a no-op for this node.
 */
export function applyRuleToToken(rule: RippleRule, currentToken: string): string | null {
  const { property } = rule;

  switch (rule.kind) {
    case "semantic-swap":
    case "literal": {
      const next = rule.token ?? rule.literal ?? null;
      return next && next !== currentToken ? next : null;
    }
    case "scale-step": {
      const idx = tokenIndex(property, currentToken);
      if (idx < 0 || !rule.steps) return null;
      const scale = scaleFor(property);
      const nextIdx = Math.min(scale.length - 1, Math.max(0, idx + rule.steps));
      const next = scale[nextIdx]!.token;
      return next !== currentToken ? next : null;
    }
    case "relative-delta": {
      const value = tokenValue(property, currentToken);
      if (value === null || !rule.ratio) return null;
      if (value === 0) return null;
      const next = nearestToken(property, value * rule.ratio);
      if (next && next !== currentToken) return next;
      // Rounding swallowed the change on a small token — still honour the
      // design decision by moving one step in the same direction.
      const idx = tokenIndex(property, currentToken);
      const scale = scaleFor(property);
      if (idx < 0 || rule.ratio === 1) return null;
      const dir = rule.ratio > 1 ? 1 : -1;
      const stepped = scale[Math.min(scale.length - 1, Math.max(0, idx + dir))]!.token;
      return stepped !== currentToken ? stepped : null;
    }

    case "token-switch": {
      const band = rule.token;
      if (!band) return null;
      const target = DENSITY_BANDS.find((b) => b.token === band);
      if (!target) return null;
      const currentBand = densityOf(property, currentToken);
      if (currentBand === band) return null;
      // Re-derive from the band's representative value.
      const representative =
        band === "compact" ? 8 : band === "cozy" ? 16 : 24;
      const next = nearestToken(property, representative);
      return next !== currentToken ? next : null;
    }
    default:
      return null;
  }
}
