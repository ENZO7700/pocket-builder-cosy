import type { RawNode } from "../semantic-intent/types";
import { flatten, mapNodes } from "./canonicalIntent";
import { readToken, tokenValue } from "./ruleInference";
import type { GuardViolation, IntentConflict, IntentRole } from "./types";

const TOUCH_CLASSES = ["min-h-[44px]", "min-w-[44px]", "inline-flex", "items-center"];

/**
 * Live self-audit.
 * - Hard contracts always apply (a11y, 44pt touch, mobile safety).
 * - Drift checks are skipped for claims the user has consciously set.
 */
export function auditIntent(ast: RawNode[]): GuardViolation[] {
  const nodes = flatten(ast);
  const violations: GuardViolation[] = [];

  // ---- Hard contracts -------------------------------------------------
  for (const node of nodes) {
    const classes = (node.className ?? "").split(/\s+/).filter(Boolean);
    const interactive = node.type === "button" || node.type === "input" || Boolean(node.action);

    if (interactive && !TOUCH_CLASSES.every((c) => classes.includes(c))) {
      violations.push({
        id: `touch-${node.id}`,
        nodeId: node.id,
        severity: "contract",
        message: "Touch target below 44pt (iPhone 17 Air contract).",
        fixClasses: TOUCH_CLASSES,
      });
    }

    if (node.type === "input" && !node.label && !node.name) {
      violations.push({
        id: `a11y-${node.id}`,
        nodeId: node.id,
        severity: "contract",
        message: "Form field has no label or name — screen readers cannot announce it.",
      });
    }

    if (classes.some((c) => /^w-\[\d+px\]$/.test(c))) {
      violations.push({
        id: `rigid-${node.id}`,
        nodeId: node.id,
        severity: "contract",
        message: "Rigid pixel width breaks mobile layout.",
        fixClasses: ["w-full", "max-w-full"],
        removePrefixes: ["w-["],
      });
    }
  }

  // ---- Drift against the canonical layer ------------------------------
  const primaries = nodes.filter((n) => n.intent?.role.value === "primary-cta");
  const secondaries = nodes.filter((n) => n.intent?.role.value === "secondary-cta");

  for (const primary of primaries) {
    if (primary.intent?.role.source === "user" && primary.intent.role.confidence >= 1) {
      // Still check weight, but never against an overridden claim below.
    }
    const primaryWeight = visualWeight(primary);
    const strongerSibling = secondaries.find((s) => visualWeight(s) > primaryWeight);
    if (strongerSibling) {
      violations.push({
        id: `weight-${primary.id}`,
        nodeId: primary.id,
        severity: "drift",
        message: `Role is primary-cta but "${strongerSibling.id}" now carries more visual weight.`,
      });
    }
  }

  const headings = nodes.filter((n) => n.intent?.role.value === "hero-heading");
  const body = nodes.filter((n) => n.intent?.role.value === "body-text");
  for (const heading of headings) {
    const headingSize = tokenValue("fontSize", readToken(heading, "fontSize") ?? "") ?? 0;
    const collapsed = body.find(
      (b) => (tokenValue("fontSize", readToken(b, "fontSize") ?? "") ?? 0) >= headingSize,
    );
    if (collapsed && headingSize > 0) {
      violations.push({
        id: `scale-${heading.id}`,
        nodeId: heading.id,
        severity: "drift",
        message: `Type scale collapsed: body copy "${collapsed.id}" is no longer smaller than the hero heading.`,
      });
    }
  }

  return violations;
}

function visualWeight(node: RawNode): number {
  const classes = node.className ?? "";
  let weight = 0;
  weight += tokenValue("fontSize", readToken(node, "fontSize") ?? "") ?? 14;
  if (/bg-(indigo|emerald|rose|accent)/.test(classes)) weight += 20;
  if (/bg-transparent|bg-white/.test(classes)) weight -= 5;
  if (/font-(bold|semibold)/.test(classes)) weight += 6;
  weight += (tokenValue("padding", readToken(node, "padding") ?? "") ?? 0) / 4;
  return weight;
}

/**
 * Did this edit contradict a claim the vision model inferred?
 * If so the workspace asks — it never scolds.
 */
export function detectConflict(before: RawNode, after: RawNode): IntentConflict | null {
  const claim = after.intent?.role;
  if (!claim || claim.source === "user") return null;

  const wasDominant = isDominantStyling(before);
  const isDominant = isDominantStyling(after);

  if (claim.value === "primary-cta" && wasDominant && !isDominant) {
    return {
      nodeId: after.id,
      claim: "role",
      inferredValue: claim.value,
      suggestedValue: "secondary-cta" as IntentRole,
      reason: "You demoted the visual weight of an element the screenshot read as the primary CTA.",
    };
  }

  if (claim.value === "secondary-cta" && !wasDominant && isDominant) {
    return {
      nodeId: after.id,
      claim: "role",
      inferredValue: claim.value,
      suggestedValue: "primary-cta" as IntentRole,
      reason: "You promoted a supporting action to the strongest element on screen.",
    };
  }

  return null;
}

function isDominantStyling(node: RawNode): boolean {
  const classes = node.className ?? "";
  return /bg-(indigo|emerald|rose|accent)/.test(classes);
}

/** One-click fix: add contract classes, drop offending prefixes. */
export function applyGuardFix(ast: RawNode[], violation: GuardViolation): RawNode[] {
  return mapNodes(ast, (node) => {
    if (node.id !== violation.nodeId) return node;
    let classes = (node.className ?? "").split(/\s+/).filter(Boolean);
    if (violation.removePrefixes?.length) {
      classes = classes.filter((c) => !violation.removePrefixes!.some((p) => c.startsWith(p)));
    }
    for (const add of violation.fixClasses ?? []) {
      if (!classes.includes(add)) classes.push(add);
    }
    return { ...node, className: classes.join(" ") };
  });
}
