import type { RawNode } from "../semantic-intent/types";
import {
  SOURCE_PRIORITY,
  type IntentClaim,
  type IntentRelation,
  type IntentRole,
  type IntentSource,
  type NodeIntent,
} from "./types";

function now(): string {
  return new Date().toISOString();
}

export function makeClaim<T>(
  value: T,
  source: IntentSource,
  confidence = source === "user" ? 1 : 0.6,
): IntentClaim<T> {
  return { value, source, confidence, lastConfirmedAt: now() };
}

/**
 * Single choke point for writing intent.
 * Priority: user > project-rules > vision.
 * A lower-priority source can never overwrite a higher-priority claim.
 * Equal priority: the newer claim wins.
 */
export function resolveClaim<T>(
  existing: IntentClaim<T> | undefined,
  incoming: IntentClaim<T>,
): IntentClaim<T> {
  if (!existing) return incoming;

  const existingRank = SOURCE_PRIORITY[existing.source];
  const incomingRank = SOURCE_PRIORITY[incoming.source];

  if (incomingRank < existingRank) {
    // Proposal only — keep the authoritative claim, just refresh its timestamp.
    return existing;
  }

  const sameValue = JSON.stringify(existing.value) === JSON.stringify(incoming.value);
  if (sameValue) {
    // Confirming an inferred claim promotes its provenance: the user now owns it.
    const source = incomingRank > existingRank ? incoming.source : existing.source;
    return {
      ...existing,
      source,
      confidence: Math.max(existing.confidence, incoming.confidence),
      lastConfirmedAt: now(),
    };
  }


  return {
    ...incoming,
    lastConfirmedAt: now(),
    overriddenBy: {
      source: incoming.source,
      previousValue: existing.value,
      at: now(),
    },
  };
}

export function defaultIntent(role: IntentRole = "unknown", source: IntentSource = "vision"): NodeIntent {
  return {
    role: makeClaim<IntentRole>(role, source, source === "user" ? 1 : 0.5),
    relations: makeClaim<IntentRelation[]>([], source, 0.4),
  };
}

/** Immutably write a role claim through the priority resolver. */
export function setRole(
  intent: NodeIntent | undefined,
  role: IntentRole,
  source: IntentSource,
  confidence?: number,
): NodeIntent {
  const base = intent ?? defaultIntent();
  return { ...base, role: resolveClaim(base.role, makeClaim<IntentRole>(role, source, confidence)) };
}

export function setRationale(
  intent: NodeIntent | undefined,
  rationale: string,
  source: IntentSource,
  confidence?: number,
): NodeIntent {
  const base = intent ?? defaultIntent();
  return {
    ...base,
    rationale: resolveClaim(base.rationale, makeClaim(rationale, source, confidence)),
  };
}

export function setRelations(
  intent: NodeIntent | undefined,
  relations: IntentRelation[],
  source: IntentSource,
  confidence?: number,
): NodeIntent {
  const base = intent ?? defaultIntent();
  return {
    ...base,
    relations: resolveClaim(base.relations, makeClaim(relations, source, confidence)),
  };
}

/** True when a claim has been consciously set by the user. */
export function isUserOwned(claim: IntentClaim<unknown> | undefined): boolean {
  return claim?.source === "user";
}

/* ------------------------------------------------------------------ */
/* AST helpers                                                         */
/* ------------------------------------------------------------------ */

export function walk(nodes: RawNode[], visit: (node: RawNode) => void): void {
  for (const node of nodes) {
    visit(node);
    if (node.children?.length) walk(node.children, visit);
  }
}

export function flatten(nodes: RawNode[]): RawNode[] {
  const out: RawNode[] = [];
  walk(nodes, (n) => out.push(n));
  return out;
}

export function mapNodes(nodes: RawNode[], fn: (node: RawNode) => RawNode): RawNode[] {
  return nodes.map((node) => {
    const mapped = fn(node);
    if (mapped.children?.length) {
      return { ...mapped, children: mapNodes(mapped.children, fn) };
    }
    return mapped;
  });
}

export function findNode(nodes: RawNode[], id: string): RawNode | null {
  for (const node of nodes) {
    if (node.id === id) return node;
    if (node.children?.length) {
      const found = findNode(node.children, id);
      if (found) return found;
    }
  }
  return null;
}

/**
 * Seed the canonical layer for nodes that have no intent yet, using cheap
 * structural heuristics. Vision-sourced, so any user claim outranks it.
 */
export function seedIntent(nodes: RawNode[]): RawNode[] {
  const buttons = flatten(nodes).filter((n) => n.type === "button");
  const primaryId = buttons.find((b) => b.action === "submit")?.id ?? buttons[0]?.id;

  return mapNodes(nodes, (node) => {
    if (node.intent) return node;

    let role: IntentRole = "container";
    let rationale = "Structural container inferred from layout.";

    if (node.type === "button") {
      role = node.id === primaryId ? "primary-cta" : "secondary-cta";
      rationale =
        role === "primary-cta"
          ? "Dominant action of the screen — highest visual weight in the source design."
          : "Supporting action next to the primary call to action.";
    } else if (node.type === "input") {
      role = "form-field";
      rationale = "Data entry control inside a form rhythm group.";
    } else if (node.type === "text") {
      const cls = node.className ?? "";
      const isBig = /text-(3xl|4xl|5xl|6xl|7xl)/.test(cls);
      role = isBig ? "hero-heading" : /text-(xl|2xl)/.test(cls) ? "heading" : "body-text";
      rationale = isBig
        ? "Largest type on the canvas — anchors the visual hierarchy."
        : "Supporting copy following the established type scale.";
    } else if (node.type === "list") {
      role = "card-grid-item";
      rationale = "Repeating collection sharing one rhythm.";
    }

    const relations: IntentRelation[] = [];
    if (role === "primary-cta" || role === "secondary-cta") {
      relations.push({ kind: "variant-of", group: "cta" });
    }
    if (role === "form-field") {
      relations.push({ kind: "sibling-set", group: "form-fields" });
    }
    if (role === "hero-heading" || role === "heading" || role === "body-text") {
      relations.push({ kind: "same-rhythm-as", group: "type-scale" });
    }

    let intent = defaultIntent(role, "vision");
    intent = setRationale(intent, rationale, "vision", 0.55);
    intent = setRelations(intent, relations, "vision", 0.5);
    return { ...node, intent };
  });
}
