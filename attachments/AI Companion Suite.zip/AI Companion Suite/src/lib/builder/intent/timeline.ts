import type { RawNode } from "../semantic-intent/types";
import type { IntentRole, IntentSource, TimelineChangeKind, TimelineEntry } from "./types";

export const MAIN_BRANCH = "main";

export interface AppendArgs {
  kind: TimelineChangeKind;
  summary: string;
  source: IntentSource;
  snapshot: RawNode[];
  nodeId?: string;
  role?: IntentRole;
  branch?: string;
}

/**
 * Intent Diff Timeline — an explainable design changelog.
 * Entries are keyed on *why* something changed, and each carries a full AST
 * snapshot so any point can be re-rendered or branched from.
 */
export class IntentTimeline {
  private entries: TimelineEntry[] = [];
  private counter = 0;

  public append(args: AppendArgs): TimelineEntry {
    const entry: TimelineEntry = {
      id: `t${++this.counter}`,
      at: new Date().toISOString(),
      kind: args.kind,
      summary: args.summary,
      source: args.source,
      snapshot: structuredCloneSafe(args.snapshot),
      branch: args.branch ?? MAIN_BRANCH,
      ...(args.nodeId ? { nodeId: args.nodeId } : {}),
      ...(args.role ? { role: args.role } : {}),
    };
    this.entries.push(entry);
    return entry;
  }

  public list(branch?: string): TimelineEntry[] {
    return branch ? this.entries.filter((e) => e.branch === branch) : [...this.entries];
  }

  public branches(): string[] {
    return Array.from(new Set(this.entries.map((e) => e.branch)));
  }

  public get(id: string): TimelineEntry | undefined {
    return this.entries.find((e) => e.id === id);
  }

  /** Time travel: the AST as it was at this entry. */
  public restore(id: string): RawNode[] | null {
    const entry = this.get(id);
    return entry ? (entry.snapshot as RawNode[]) : null;
  }

  /** Fork a new direction from any point without losing the original. */
  public branchFrom(id: string, branchName: string): TimelineEntry | null {
    const entry = this.get(id);
    if (!entry) return null;
    return this.append({
      kind: entry.kind,
      summary: `Branched "${branchName}" from ${entry.id}`,
      source: "user",
      snapshot: entry.snapshot as RawNode[],
      branch: branchName,
    });
  }

  /** Compare two entries: which nodes differ. */
  public diff(aId: string, bId: string): string[] {
    const a = this.get(aId);
    const b = this.get(bId);
    if (!a || !b) return [];
    const mapA = indexById(a.snapshot as RawNode[]);
    const mapB = indexById(b.snapshot as RawNode[]);
    const ids = new Set([...mapA.keys(), ...mapB.keys()]);
    const changed: string[] = [];
    for (const id of ids) {
      if (JSON.stringify(mapA.get(id)) !== JSON.stringify(mapB.get(id))) changed.push(id);
    }
    return changed;
  }

  public clear(): void {
    this.entries = [];
    this.counter = 0;
  }
}

function indexById(nodes: RawNode[], map = new Map<string, RawNode>()): Map<string, RawNode> {
  for (const node of nodes) {
    map.set(node.id, { ...node, children: undefined });
    if (node.children?.length) indexById(node.children, map);
  }
  return map;
}

function structuredCloneSafe<T>(value: T): T {
  return JSON.parse(JSON.stringify(value)) as T;
}
