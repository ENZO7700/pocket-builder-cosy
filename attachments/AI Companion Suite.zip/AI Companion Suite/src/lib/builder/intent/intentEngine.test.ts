import { describe, it, expect } from "vitest";
import type { RawNode } from "../semantic-intent/types";
import {
  IntentTimeline,
  applyGuardFix,
  applyRipple,
  applyRuleToToken,
  auditIntent,
  computeRipple,
  defaultIntent,
  detectConflict,
  detectEdit,
  findNode,
  flatten,
  inferRules,
  isUserOwned,
  makeClaim,
  mapNodes,
  nearestToken,
  readToken,
  relatedNodes,
  resolveClaim,
  seedIntent,
  setRationale,
  setRelations,
  setRole,
  tokenIndex,
  tokenValue,
  writeToken,
  type EditDelta,
  type IntentRole,
} from "./index";

/* ------------------------------------------------------------------ */
/* Fixtures                                                            */
/* ------------------------------------------------------------------ */

function sampleAST(): RawNode[] {
  return [
    {
      id: "root",
      type: "box",
      className: "p-4 rounded-lg",
      children: [
        { id: "hero", type: "text", text: "Welcome", className: "text-4xl font-bold" },
        { id: "sub", type: "text", text: "Sub copy", className: "text-sm" },
        {
          id: "cta",
          type: "button",
          text: "Buy",
          action: "submit",
          className: "bg-indigo-600 rounded-lg p-4 min-h-[44px] min-w-[44px] inline-flex items-center",
        },
        {
          id: "cta2",
          type: "button",
          text: "Learn more",
          className: "bg-transparent rounded-lg p-2 min-h-[44px] min-w-[44px] inline-flex items-center",
        },
        { id: "email", type: "input", name: "email", label: "Email", className: "p-2 rounded min-h-[44px] min-w-[44px] inline-flex items-center" },
      ],
    },
  ];
}

/* ------------------------------------------------------------------ */
/* Canonical intent layer                                              */
/* ------------------------------------------------------------------ */

describe("canonical intent — claim resolution priority", () => {
  it("user claim outranks vision claim", () => {
    const vision = makeClaim<IntentRole>("primary-cta", "vision");
    const user = makeClaim<IntentRole>("secondary-cta", "user");
    expect(resolveClaim(vision, user).value).toBe("secondary-cta");
    expect(resolveClaim(vision, user).overriddenBy?.previousValue).toBe("primary-cta");
  });

  it("vision cannot overwrite a user claim", () => {
    const user = makeClaim<IntentRole>("secondary-cta", "user");
    const vision = makeClaim<IntentRole>("primary-cta", "vision");
    expect(resolveClaim(user, vision).value).toBe("secondary-cta");
    expect(resolveClaim(user, vision).source).toBe("user");
  });

  it("project-rules sits between user and vision", () => {
    const vision = makeClaim<IntentRole>("body-text", "vision");
    const rules = makeClaim<IntentRole>("heading", "project-rules");
    expect(resolveClaim(vision, rules).value).toBe("heading");
    expect(resolveClaim(makeClaim<IntentRole>("nav", "user"), rules).value).toBe("nav");
  });

  it("same value at equal priority only refreshes confidence", () => {
    const a = makeClaim<IntentRole>("nav", "vision", 0.4);
    const b = makeClaim<IntentRole>("nav", "vision", 0.9);
    const out = resolveClaim(a, b);
    expect(out.confidence).toBe(0.9);
    expect(out.overriddenBy).toBeUndefined();
  });

  it("setRole / setRationale / setRelations write through the resolver", () => {
    let intent = defaultIntent("container", "vision");
    intent = setRole(intent, "primary-cta", "user");
    intent = setRationale(intent, "Because the user said so", "user");
    intent = setRelations(intent, [{ kind: "variant-of", group: "cta" }], "user");
    expect(intent.role.value).toBe("primary-cta");
    expect(isUserOwned(intent.role)).toBe(true);
    expect(intent.rationale?.value).toContain("user said");
    expect(intent.relations.value[0]!.group).toBe("cta");
    // vision can no longer take it back
    expect(setRole(intent, "body-text", "vision").role.value).toBe("primary-cta");
  });
});

describe("AST helpers", () => {
  it("flatten / findNode / mapNodes traverse deeply", () => {
    const ast = sampleAST();
    expect(flatten(ast)).toHaveLength(6);
    expect(findNode(ast, "cta")?.text).toBe("Buy");
    expect(findNode(ast, "nope")).toBeNull();
    const renamed = mapNodes(ast, (n) => (n.id === "hero" ? { ...n, text: "Hi" } : n));
    expect(findNode(renamed, "hero")?.text).toBe("Hi");
    expect(findNode(ast, "hero")?.text).toBe("Welcome"); // immutability
  });
});

describe("seedIntent heuristics", () => {
  const seeded = seedIntent(sampleAST());
  const byId = (id: string) => findNode(seeded, id)!;

  it("marks the submit button as the primary CTA and the other as secondary", () => {
    expect(byId("cta").intent?.role.value).toBe("primary-cta");
    expect(byId("cta2").intent?.role.value).toBe("secondary-cta");
  });

  it("classifies typography by scale", () => {
    expect(byId("hero").intent?.role.value).toBe("hero-heading");
    expect(byId("sub").intent?.role.value).toBe("body-text");
  });

  it("classifies inputs as form fields with a sibling-set relation", () => {
    expect(byId("email").intent?.role.value).toBe("form-field");
    expect(byId("email").intent?.relations.value[0]!.group).toBe("form-fields");
  });

  it("is vision-sourced and never overwrites existing intent", () => {
    expect(byId("cta").intent?.role.source).toBe("vision");
    const withUser = mapNodes(seeded, (n) =>
      n.id === "cta" ? { ...n, intent: setRole(n.intent, "nav", "user") } : n,
    );
    expect(findNode(seedIntent(withUser), "cta")?.intent?.role.value).toBe("nav");
  });
});

/* ------------------------------------------------------------------ */
/* Rule inference                                                      */
/* ------------------------------------------------------------------ */

describe("rule inference — tokens", () => {
  it("reads and writes tokens without duplicating classes", () => {
    const node: RawNode = { id: "n", type: "box", className: "p-4 rounded-lg text-sm" };
    expect(readToken(node, "padding")).toBe("p-4");
    expect(readToken(node, "radius")).toBe("rounded-lg");
    expect(readToken(node, "fontSize")).toBe("text-sm");
    expect(readToken(node, "colorRole")).toBeNull();
    const written = writeToken(node, "padding", "p-8");
    expect(written.className).toContain("p-8");
    expect(written.className).not.toContain("p-4");
  });

  it("exposes a monotonic scale", () => {
    expect(tokenIndex("radius", "rounded-lg")).toBeGreaterThan(tokenIndex("radius", "rounded-sm"));
    expect(tokenValue("fontSize", "text-2xl")).toBe(24);
    expect(nearestToken("padding", 17)).toBe("p-4");
  });

  it("infers a scale-step rule for a one-step typography bump", () => {
    const delta: EditDelta = {
      nodeId: "hero",
      property: "fontSize",
      beforeToken: "text-2xl",
      afterToken: "text-3xl",
    };
    const rules = inferRules(delta);
    expect(rules.length).toBeGreaterThan(0);
    expect(rules.map((r) => r.kind)).toContain("scale-step");
  });

  it("infers a relative-delta rule for a proportional radius change", () => {
    const rules = inferRules({
      nodeId: "cta",
      property: "radius",
      beforeToken: "rounded-lg",
      afterToken: "rounded-xl",
    });
    expect(rules.some((r) => r.kind === "relative-delta" || r.kind === "scale-step")).toBe(true);
    expect(rules[0]!.confidence).toBeGreaterThanOrEqual(rules[rules.length - 1]!.confidence);
  });

  it("infers a semantic swap for colour role changes", () => {
    const rules = inferRules({
      nodeId: "cta",
      property: "colorRole",
      beforeToken: "bg-indigo-600",
      afterToken: "bg-emerald-600",
    });
    expect(rules.some((r) => r.kind === "semantic-swap" || r.kind === "literal")).toBe(true);
  });

  it("applies a rule to a different starting token (decision, not value)", () => {
    const [rule] = inferRules({
      nodeId: "a",
      property: "radius",
      beforeToken: "rounded-lg",
      afterToken: "rounded-xl",
    });
    const next = applyRuleToToken(rule!, "rounded-sm");
    expect(next).not.toBe("rounded-xl");
    expect(next).toBeTruthy();
  });

  it("detectEdit returns null when nothing tokenised changed", () => {
    const a: RawNode = { id: "x", type: "box", className: "p-4" };
    expect(detectEdit(a, { ...a, text: "different" })).toBeNull();
    expect(detectEdit(a, { ...a, className: "p-8" })?.afterToken).toBe("p-8");
  });
});

/* ------------------------------------------------------------------ */
/* Ripple engine                                                       */
/* ------------------------------------------------------------------ */

describe("ripple engine", () => {
  const ast = seedIntent(sampleAST());

  it("relates nodes by intent group, not DOM proximity", () => {
    const related = relatedNodes(ast, "cta").map((n) => n.id);
    expect(related).toContain("cta2");
    expect(related).not.toContain("cta");
    expect(related).not.toContain("email");
  });

  it("proposes rule-derived changes for related nodes only", () => {
    const delta: EditDelta = {
      nodeId: "cta",
      property: "radius",
      beforeToken: "rounded-lg",
      afterToken: "rounded-2xl",
    };
    const rule = inferRules(delta)[0]!;
    const proposals = computeRipple(ast, delta, rule);
    expect(proposals.length).toBeGreaterThan(0);
    expect(proposals.every((p) => p.nodeId !== "cta")).toBe(true);
    expect(proposals[0]!.reason).toBe(rule.label);
  });

  it("applies only accepted proposals, atomically", () => {
    const delta: EditDelta = {
      nodeId: "cta",
      property: "radius",
      beforeToken: "rounded-lg",
      afterToken: "rounded-2xl",
    };
    const rule = inferRules(delta)[0]!;
    const proposals = computeRipple(ast, delta, rule);
    const next = applyRipple(ast, proposals);
    for (const p of proposals) {
      expect(readToken(findNode(next, p.nodeId)!, p.property)).toBe(p.afterToken);
    }
    expect(applyRipple(ast, [])).toBe(ast);
  });
});

/* ------------------------------------------------------------------ */
/* Guard                                                               */
/* ------------------------------------------------------------------ */

describe("intent guard", () => {
  it("flags touch targets under 44pt as a hard contract break", () => {
    const ast: RawNode[] = [{ id: "b", type: "button", className: "p-1", text: "x" }];
    const violations = auditIntent(ast);
    expect(violations.some((v) => v.id.startsWith("touch-") && v.severity === "contract")).toBe(true);
  });

  it("flags unlabelled inputs", () => {
    const ast: RawNode[] = [{ id: "i", type: "input", className: "p-1" }];
    expect(auditIntent(ast).some((v) => v.id.startsWith("a11y-"))).toBe(true);
  });

  it("flags rigid pixel widths and fixes them on demand", () => {
    const ast: RawNode[] = [
      { id: "w", type: "box", className: "w-[320px] p-4" },
    ];
    const violation = auditIntent(ast).find((v) => v.id.startsWith("rigid-"))!;
    expect(violation).toBeTruthy();
    const fixed = applyGuardFix(ast, violation);
    expect(fixed[0]!.className).toContain("w-full");
    expect(fixed[0]!.className).not.toContain("w-[320px]");
  });

  it("stays silent on a clean AST", () => {
    const clean: RawNode[] = [
      {
        id: "ok",
        type: "button",
        text: "Go",
        className: "min-h-[44px] min-w-[44px] inline-flex items-center p-4",
      },
    ];
    expect(auditIntent(clean)).toHaveLength(0);
  });

  it("reports drift when a secondary CTA outweighs the primary", () => {
    const ast = seedIntent(sampleAST());
    const drifted = mapNodes(ast, (n) =>
      n.id === "cta"
        ? { ...n, className: "bg-white rounded-lg p-2 min-h-[44px] min-w-[44px] inline-flex items-center" }
        : n.id === "cta2"
          ? { ...n, className: "bg-indigo-600 font-bold rounded-lg p-8 min-h-[44px] min-w-[44px] inline-flex items-center" }
          : n,
    );
    expect(auditIntent(drifted).some((v) => v.severity === "drift")).toBe(true);
  });

  it("asks instead of scolding when the user contradicts a vision claim", () => {
    const before: RawNode = {
      id: "cta",
      type: "button",
      className: "bg-indigo-600",
      intent: defaultIntent("primary-cta", "vision"),
    };
    const after: RawNode = { ...before, className: "bg-white" };
    const conflict = detectConflict(before, after)!;
    expect(conflict.suggestedValue).toBe("secondary-cta");

    const promoted = detectConflict(
      { ...before, className: "bg-white", intent: defaultIntent("secondary-cta", "vision") },
      { ...before, className: "bg-emerald-600", intent: defaultIntent("secondary-cta", "vision") },
    );
    expect(promoted?.suggestedValue).toBe("primary-cta");
  });

  it("never questions a claim the user owns", () => {
    const before: RawNode = {
      id: "cta",
      type: "button",
      className: "bg-indigo-600",
      intent: setRole(defaultIntent("primary-cta", "vision"), "primary-cta", "user"),
    };
    expect(detectConflict(before, { ...before, className: "bg-white" })).toBeNull();
  });
});

/* ------------------------------------------------------------------ */
/* Timeline                                                            */
/* ------------------------------------------------------------------ */

describe("intent timeline", () => {
  it("records, restores, branches and diffs", () => {
    const timeline = new IntentTimeline();
    const v1 = seedIntent(sampleAST());
    const a = timeline.append({
      kind: "vision-import",
      source: "vision",
      summary: "Imported design",
      snapshot: v1,
    });
    const v2 = mapNodes(v1, (n) => (n.id === "cta" ? { ...n, className: "bg-emerald-600" } : n));
    const b = timeline.append({
      kind: "property-edit",
      source: "user",
      summary: "cta colour",
      snapshot: v2,
      nodeId: "cta",
    });

    expect(timeline.list()).toHaveLength(2);
    expect(timeline.restore(a.id)![0]!.children![2]!.className).toContain("bg-indigo-600");
    expect(timeline.diff(a.id, b.id)).toEqual(["cta"]);
    expect(timeline.diff(a.id, "missing")).toEqual([]);

    const branch = timeline.branchFrom(a.id, "experiment")!;
    expect(branch.branch).toBe("experiment");
    expect(timeline.branches()).toContain("experiment");
    expect(timeline.list("experiment")).toHaveLength(1);
    expect(timeline.branchFrom("nope", "x")).toBeNull();

    timeline.clear();
    expect(timeline.list()).toHaveLength(0);
  });

  it("snapshots are deep copies — later mutation cannot rewrite history", () => {
    const timeline = new IntentTimeline();
    const ast = sampleAST();
    const entry = timeline.append({
      kind: "vision-import",
      source: "vision",
      summary: "import",
      snapshot: ast,
    });
    ast[0]!.className = "MUTATED";
    expect(timeline.restore(entry.id)![0]!.className).not.toBe("MUTATED");
  });
});
