/**
 * Canonical Intent Layer — types.
 *
 * The intent layer is *canonical*, not archival: it stores the current,
 * authoritative design intent per node. Vision is only the first source;
 * an explicit user decision always outranks it.
 */

export type IntentSource = "user" | "project-rules" | "vision";

export const SOURCE_PRIORITY: Record<IntentSource, number> = {
  user: 3,
  "project-rules": 2,
  vision: 1,
};

export type IntentRole =
  | "primary-cta"
  | "secondary-cta"
  | "nav"
  | "hero-heading"
  | "heading"
  | "body-text"
  | "form-field"
  | "card-grid-item"
  | "container"
  | "unknown";

export const INTENT_ROLES: IntentRole[] = [
  "primary-cta",
  "secondary-cta",
  "nav",
  "hero-heading",
  "heading",
  "body-text",
  "form-field",
  "card-grid-item",
  "container",
  "unknown",
];

export type RelationKind = "aligned-with" | "same-rhythm-as" | "variant-of" | "sibling-set";

export interface IntentRelation {
  kind: RelationKind;
  /** Logical group key — all nodes sharing it are related. */
  group: string;
}

export interface IntentClaim<T> {
  value: T;
  source: IntentSource;
  /** 0..1 */
  confidence: number;
  lastConfirmedAt: string;
  overriddenBy?: {
    source: IntentSource;
    previousValue: T;
    at: string;
  };
}

export interface NodeIntent {
  role: IntentClaim<IntentRole>;
  rationale?: IntentClaim<string>;
  relations: IntentClaim<IntentRelation[]>;
}

/** A pending "you contradicted an inferred claim" question. */
export interface IntentConflict {
  nodeId: string;
  claim: "role";
  inferredValue: IntentRole;
  suggestedValue: IntentRole;
  reason: string;
}

export type RuleKind =
  | "relative-delta"
  | "scale-step"
  | "token-switch"
  | "semantic-swap"
  | "literal";

export type EditProperty = "radius" | "padding" | "fontSize" | "colorRole";

export interface EditDelta {
  nodeId: string;
  property: EditProperty;
  beforeToken: string;
  afterToken: string;
}

export interface RippleRule {
  kind: RuleKind;
  property: EditProperty;
  /** Human-readable chip label, e.g. "+50% corner softness". */
  label: string;
  confidence: number;
  /** Rule payload — meaning depends on kind. */
  ratio?: number;
  steps?: number;
  token?: string;
  literal?: string;
}

export interface RippleProposal {
  nodeId: string;
  property: EditProperty;
  beforeToken: string;
  afterToken: string;
  reason: string;
}

export type GuardSeverity = "contract" | "drift";

export interface GuardViolation {
  id: string;
  nodeId: string;
  severity: GuardSeverity;
  message: string;
  /** Tailwind classes to add when the user clicks Fix. */
  fixClasses?: string[];
  /** Classes to remove when fixing. */
  removePrefixes?: string[];
}

export type TimelineChangeKind =
  | "vision-import"
  | "property-edit"
  | "ripple"
  | "guard-fix"
  | "intent-redefined"
  | "intent-drift-kept"
  | "scoped-ai-edit"
  | "node-deleted";

export interface TimelineEntry {
  id: string;
  at: string;
  kind: TimelineChangeKind;
  nodeId?: string;
  role?: IntentRole;
  source: IntentSource;
  summary: string;
  /** Branch this entry belongs to. */
  branch: string;
  /** Full AST snapshot for time travel. */
  snapshot: unknown;
}
