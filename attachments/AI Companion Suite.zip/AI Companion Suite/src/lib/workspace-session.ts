import { supabase } from "@/integrations/supabase/client";
import { openWorkspaceSession } from "@/lib/gate.functions";
import {
  currentBrowserTrace,
  describeAuthHeader,
  startSpan,
  type Span,
} from "@/lib/observability/trace";

const EXPIRY_SAFETY_SECONDS = 60;

let bootstrapping: Promise<string | null> | null = null;
let bootstrapCallInProgress = false;
let validatedToken: string | null = null;

export class WorkspaceUnavailableError extends Error {
  constructor(message = "Workspace is temporarily unavailable. Please retry in a moment.") {
    super(message);
    this.name = "WorkspaceUnavailableError";
  }
}

function sessionIsFresh(expiresAt: number | undefined): boolean {
  return typeof expiresAt === "number" && expiresAt > Date.now() / 1000 + EXPIRY_SAFETY_SECONDS;
}

async function bootstrapWorkspaceSession(parent: Span): Promise<string | null> {
  const span = parent.child("workspace.session.bootstrap");
  bootstrapCallInProgress = true;
  try {
    const result = await openWorkspaceSession();
    if (!result.session) {
      span.fail(new Error(result.error ?? "no session returned"), { phase: "open" });
      throw new WorkspaceUnavailableError();
    }

    const { data, error } = await supabase.auth.setSession(result.session);
    if (error || !data.session?.access_token) {
      span.fail(error ?? new Error("setSession returned no token"), { phase: "set-session" });
      throw new WorkspaceUnavailableError("Workspace session could not be opened. Please retry.");
    }
    validatedToken = data.session.access_token;
    span.end({ ...describeAuthHeader(`Bearer ${validatedToken}`) });
    return validatedToken;
  } finally {
    bootstrapCallInProgress = false;
  }
}

/**
 * Return a verified shared-workspace token. All callers share one bootstrap so
 * route loading, server functions, and chat streaming cannot race each other.
 */
export async function ensureWorkspaceAccessToken(options?: {
  forceRefresh?: boolean;
  allowMissing?: boolean;
}): Promise<string | null> {
  if (typeof window === "undefined") return null;

  // openWorkspaceSession is itself a server function and therefore traverses
  // the global function middleware. Do not recursively bootstrap that call.
  if (bootstrapCallInProgress) return null;

  const span = startSpan("workspace.session.ensure", currentBrowserTrace(), {
    forceRefresh: Boolean(options?.forceRefresh),
  });

  if (!options?.forceRefresh) {
    const { data } = await supabase.auth.getSession();
    const session = data.session;
    if (session?.access_token && sessionIsFresh(session.expires_at)) {
      if (validatedToken === session.access_token) {
        span.end({ outcome: "cached" });
        return session.access_token;
      }

      // getUser verifies that a previously cached JWT still belongs to an
      // account that exists in the currently configured backend.
      const { data: verified, error } = await supabase.auth.getUser(session.access_token);
      if (!error && verified.user) {
        validatedToken = session.access_token;
        span.end({ outcome: "verified", ...describeAuthHeader(`Bearer ${session.access_token}`) });
        return session.access_token;
      }
      span.event("workspace.session.stale", {
        reason: error?.message ?? "user not found for cached token",
      });
    } else {
      span.event("workspace.session.absent_or_expiring", {
        hasToken: Boolean(session?.access_token),
      });
    }
  }

  validatedToken = null;
  await supabase.auth.signOut({ scope: "local" });
  bootstrapping ??= bootstrapWorkspaceSession(span).finally(() => {
    bootstrapping = null;
  });

  try {
    const token = await bootstrapping;
    span.end({ outcome: token ? "bootstrapped" : "no-token" });
    return token;
  } catch (error) {
    span.fail(error, { outcome: options?.allowMissing ? "missing-allowed" : "failed" });
    if (options?.allowMissing) return null;
    throw error instanceof WorkspaceUnavailableError
      ? error
      : new WorkspaceUnavailableError();
  }
}

/** Fetch wrapper used by AI SDK. A stale workspace token gets one refresh and retry. */
export async function workspaceAuthenticatedFetch(
  input: RequestInfo | URL,
  init?: RequestInit,
): Promise<Response> {
  const span = startSpan("chat.stream.request", currentBrowserTrace(), {
    url: typeof input === "string" ? input : input instanceof URL ? input.toString() : "request",
  });

  const withTrace = new Headers(init?.headers);
  withTrace.set("x-trace-id", span.traceId);
  withTrace.set("x-span-id", span.spanId);

  const first = await fetch(input, { ...init, headers: withTrace });
  if (first.status !== 401) {
    span.end({ status: first.status });
    return first;
  }

  span.event("chat.stream.unauthorized", {
    status: 401,
    ...describeAuthHeader(withTrace.get("Authorization")),
  });

  const token = await ensureWorkspaceAccessToken({ forceRefresh: true });
  if (!token) {
    span.fail(new Error("401 and no refreshed workspace token"), { status: 401 });
    return first;
  }

  withTrace.set("Authorization", `Bearer ${token}`);
  const retried = await fetch(input, { ...init, headers: withTrace });
  span.end({ status: retried.status, retried: true });
  return retried;
}

export function resetWorkspaceSessionStateForTests(): void {
  bootstrapping = null;
  bootstrapCallInProgress = false;
  validatedToken = null;
}
