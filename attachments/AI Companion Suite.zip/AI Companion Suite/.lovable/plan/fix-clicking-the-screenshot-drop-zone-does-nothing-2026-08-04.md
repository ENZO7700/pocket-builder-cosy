# Fix: clicking the screenshot drop zone does nothing

## What's wrong

In the Vision Builder drop zone, the invisible file input sits at `z-10`, but the visible content block (icon + "Drag & Drop a screenshot" text) is rendered above it at `z-20`. Every click in the middle of the card — exactly where the user aims — lands on that text block instead of the file input, so the file picker never opens. Only clicks on the thin outer margin work. Drag & drop is unaffected, which matches "click does nothing".

## The fix

1. Wrap the whole card in a `<label>` so any click anywhere in the drop zone opens the file picker, regardless of stacking order.
2. Make the inner content block non-interactive (`pointer-events-none`) so it can never swallow the click.
3. Add keyboard/a11y support: the label is focusable, Enter/Space opens the picker, and the card gets a visible focus ring.
4. Reset the input value after each selection so re-uploading the same file still triggers processing.
5. Surface failures instead of silence: if the picked file is not an image, show a short inline message under the card (today it only fires a haptic buzz and nothing else appears).

## Also verified in the same pass

- The chosen image is passed up to the builder route and sent to the Mistral Pixtral vision function, which then renders the AST. If the vision call fails (e.g. missing Mistral key), the existing error banner already shows — I'll confirm it renders after a real click-upload.

## Technical notes

- File: `src/components/builder/VisionUploader.tsx` (presentation only; no change to the vision pipeline or server functions).
- Keep the existing tilt effect, haptics, drag states, and AMOLED styling exactly as they are.
- Verify with Playwright: click the center of the drop zone, assert the file chooser event fires and an uploaded fixture image starts processing.
