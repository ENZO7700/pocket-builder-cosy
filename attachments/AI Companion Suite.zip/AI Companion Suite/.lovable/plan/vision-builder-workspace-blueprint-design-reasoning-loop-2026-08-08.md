# Vision Builder Workspace — Blueprint: "Design Reasoning Loop"

One headline capability, three sub-capabilities. Scope is limited to `/builder` (Vision Builder Workspace) and its engines under `src/lib/builder/`.

## The one thing no builder does today

Every builder on the market converts a screenshot into markup **once**, then forgets why it made each decision. The output is dead: you can edit pixels, but the tool has no model of intent, so every later change is a fresh guess.

## Main function — Intent Memory Loop (canonical, not archival)

The workspace keeps a **canonical intent layer** per node: the current, authoritative design intent — not a frozen snapshot of what the vision model first saw. The screenshot is only the first source of truth; the user outranks it.

Each node carries a set of intent claims, each claim stored as:

- `value` — e.g. role `primary-cta`, rationale, relationship `variant-of: hero-cta`
- `source` — `user` | `project-rules` | `vision`
- `confidence`
- `lastConfirmedAt`
- `overriddenBy` — which claim/action superseded it

### Conflict resolution — fixed priority

```text
explicit user intent  >  project design rules  >  inferred vision intent
```

A lower-priority source can never overwrite a higher-priority claim; it can only propose. Provenance is kept forever, so the timeline can show "vision said primary-cta, you redefined it as secondary-cta on Aug 8".

### Conscious redefinition (the answer to the CTA case)

When the user makes a change that contradicts an inferred claim, the Guard does **not** scold. It asks once, inline, as two chips:

- **"Redefine intent"** → the canonical role is rewritten (`primary-cta` → `secondary-cta`, source `user`), relationships are re-derived, and the change becomes the new baseline that ripples and guards measure against.
- **"Keep intent, treat as drift"** → the claim stays, the node is flagged as a deviation with a one-click revert.

Silence defaults to redefinition after the next unrelated edit — the system assumes the user meant it. The workspace is a collaborator, not a warden of the original screenshot.

## Sub-function 1 — Ripple Engine (propagates decisions, not pixels)

A ripple never copies a raw value. It first **infers the transformation rule** behind the edit, then applies that rule to related nodes in their own terms.

Rule classes the engine derives:

- **Relative delta** — radius 8 → 12 becomes "+50% corner softness", applied proportionally so a 4px chip becomes 6px, not 12px.
- **Scale step** — heading 32 → 40 is recognised as "+1 step on the type scale"; siblings move one step too, each from their own position.
- **Token switch** — spacing density `compact` → `comfortable`; every node in the same rhythm group re-derives its padding from the new density token.
- **Semantic swap** — colour role `accent` → `neutral`, propagated as role change, not as a hex value.
- **Literal** — fallback when no rule can be inferred with confidence.

Pipeline: detect edit → infer candidate rules with confidence → pick the highest-confidence rule (user can switch rule via chips: `+50%` / `set 12px` / `one scale step`) → resolve affected set from canonical relationships → preview with per-item accept/reject chips → dispatch as one `batch.command` so a single undo reverses everything.

Accepted ripples write back into the canonical layer with source `user`, so the design decision — not just its result — is remembered.

This is the core differentiator: propagation of design reasoning, not property synchronisation.


## Sub-function 2 — Intent Diff Timeline (time travel with reasons)

A timeline of the design, keyed on intent rather than raw AST snapshots.

- Each entry: what changed, which node role, which intent claim it reinforced, overrode, or redefined, and the source (`vision` / `user` / `project-rules` / scoped AI prompt).
- Redefinitions are first-class entries ("primary-cta → secondary-cta, redefined by user"), with the superseded claim still readable via `overriddenBy`.
- Jump to any point and re-render the canvas at that state.
- Branch from any point ("try this direction") and compare two branches side by side.
- Backed by `historyManager` + the command manager, layered with the intent metadata.

Editors give you undo. This gives you an explainable design changelog.

## Sub-function 3 — Intent Guard (live self-audit, never a warden)

A continuously running audit that scores the current AST against the **canonical** intent layer and against the platform contracts already in the repo.

- Drift checks run only against claims the user has not overridden: broken alignment groups, collapsed type scale, a role whose visual weight no longer matches.
- When a change contradicts a `vision`-sourced claim, the Guard offers redefine-vs-drift chips instead of an error (see main function).
- Hard contracts are non-negotiable and always enforced regardless of intent source: `A11yAuditorEngine`, `MobileTouchAuditor` (44pt targets), `iPhone17AirAdapter` (dvh, safe-area), spatial responsive healing.
- Each violation is a chip with a one-click **Fix** that dispatches a scoped command — and the fix is written back into the canonical layer with its provenance.

The design cannot silently rot, and the user is never corrected against their own conscious decisions.


## Workspace layout (what the user sees)

```text
┌ Vision Builder Workspace ─────────────────────────────────────┐
│ [Upload / Screenshot]        │  Live Canvas                   │
│ Tree Explorer (role badges)  │  ┌──────────────────────────┐  │
│ Inspector                    │  │  selected node outlined  │  │
│ Scoped AI prompt             │  └──────────────────────────┘  │
├──────────────────────────────┴────────────────────────────────┤
│ Intent panel: role · rationale · relations · confidence       │
│ Ripple preview chips   |  Guard chips   |  Timeline scrubber  │
└───────────────────────────────────────────────────────────────┘
```

Chip-style everywhere, single-select chips deselect back to default. Mobile: panels collapse into a full-screen sheet; desktop: secondary panels are blurred-backdrop modals below the header.

## Technical notes

- Canonical intent lives as an optional `intent` field on `RawNode` in `src/lib/builder/semantic-intent/types.ts`, holding claims of shape `{ value, source, confidence, lastConfirmedAt, overriddenBy }` — additive, so existing detector/injector/emitter keep working.
- A single `resolveClaim()` helper enforces the priority order (`user > project-rules > vision`); nothing writes intent directly.
- Vision extraction extended in `mistralVisionModel.server.ts` / `visionToHTML.server.ts`: the Pixtral prompt asks for role + rationale + relations alongside structure; strict Zod validation, graceful degrade to today's behaviour when the model omits intent.
- Rule inference for ripples is a pure, testable module (edit + node context → ranked candidate rules), separate from application — no model call needed for the common cases; Mistral is used only for ambiguous semantic swaps.
- Ripple/guard/timeline all mutate state exclusively through `commandManager` so undo/redo and CRDT multiplayer stay correct.
- Scoped AI edits (`scopedEdit.server.ts`) receive the target node's canonical claims as extra prompt context, and must return updated claims with source and confidence.
- Mistral only for all model calls, per repo rules. No new auth surface.
- Tests: unit tests per engine (priority resolution, rule inference across all rule classes, drift scoring, timeline branch/restore) plus an e2e that uploads a screenshot, demotes the CTA, and asserts the redefine chip, ripple preview, and guard chips behave as specified.

## Build order

1. Canonical intent claims + priority resolver + vision extraction + intent panel (read-only, shows provenance).
2. Intent Guard chips, including redefine-vs-drift resolution.
3. Ripple Engine: rule inference, rule-switch chips, accept/reject preview.
4. Intent Diff Timeline with branching and compare.

