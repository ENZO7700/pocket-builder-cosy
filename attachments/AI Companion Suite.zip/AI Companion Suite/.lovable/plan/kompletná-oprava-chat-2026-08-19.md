# Kompletná oprava `/chat`

## Overený stav

- Lovable Cloud je momentálne dostupný a databázové/auth požiadavky odpovedajú.
- `/api/ai-status` vracia 200, Mistral kľúč je prítomný, databáza je dostupná a povolený provider je iba Mistral.
- Čistý browser otvorí `/chat`, silent workspace session sa vytvorí, `listThreads` vráti 200 a composer sa zobrazí bez presmerovania na prihlasovanie.
- Predchádzajúci pád vznikol počas nedostupnosti backendu: bootstrap vrátil `session: null`, následná chránená server funkcia pokračovala bez Bearer tokenu a zobrazila technické `Unauthorized: No authorization header provided`.
- `/api/chat` si token získava samostatne cez `supabase.auth.getSession()`; nepoužíva rovnaký obnovovací mechanizmus ako server funkcie. Pri expirovanej/chýbajúcej session preto môže opäť poslať požiadavku bez tokenu.
- RLS je zapnuté na `threads`, `messages`, `artifacts`, `agent_settings`, `thread_memory` a `artifact_versions`; existujú owner-scoped policies.
- Aktuálne E2E testy overujú iba otvorenie `/chat` a viditeľný composer. Neoverujú odoslanie správy, stream, uloženie, reload, retry/edit, Plan/Build ani artifact flow.

## Implementácia

### 1. Jeden odolný workspace-session mechanizmus

- Vytvoriť spoločný client-safe helper, ktorý:
  - vráti platný access token z existujúcej session,
  - pri chýbajúcej alebo expirovanej session vykoná iba jeden paralelne zdieľaný bootstrap,
  - nastaví získanú session do browser klienta,
  - rozlíši nedostupný backend od neplatnej session,
  - nikdy nezavedie login/auth obrazovku.
- Použiť helper v `attachWorkspaceAuth` aj v transporte `/api/chat`, aby server funkcie a AI stream mali identické správanie.
- Odstrániť duplikovaný bootstrap medzi layoutom, middleware a chat transportom; layout zostane bez brány a iba pripraví workspace.

### 2. Správne chyby a automatické zotavenie

- Pri dočasne nedostupnom Lovable Cloud zastaviť požiadavku ešte pred chránenou server funkciou a ukázať používateľsky zrozumiteľný stav s Retry, nie interný Unauthorized stack.
- Pri 401 z `/api/chat` vykonať jedno bezpečné obnovenie shared session a jeden retry; zabrániť nekonečnej retry slučke a duplicitnému uloženiu správy.
- Zachovať typed 401/404/429/500 odpovede a mapovať ich na existujúce chat toast/error UI.
- Vylepšiť serverové logy tak, aby obsahovali fázu zlyhania a thread ID, nikdy nie token alebo tajomstvo.

### 3. Spevnenie chat pipeline

- Validovať vstup `/api/chat` (thread ID, messages, mode, client context) pred databázovými zápismi.
- Overiť vlastníctvo threadu cez aktuálnu RLS session pred streamom.
- Zabrániť duplicitnému uloženiu poslednej user správy pri retry/reconnect scenároch.
- Zachovať Mistral-only routing:
  - Build → `codestral-latest`
  - Plan → `mistral-large-latest`
- Zachovať tool stream, artifact creation, version snapshoty, memory a instant skeleton; chyby jednej pomocnej vetvy nesmú zrušiť celý stream.

### 4. Deterministické testy

- Unit testy:
  - súbežné volania spustia iba jeden session bootstrap,
  - platná, chýbajúca, expirovaná a neobnoviteľná session,
  - `/api/chat` bez tokenu, s neplatným tokenom, neexistujúcim threadom a chybným payloadom,
  - error mapping pre backend outage, Mistral 401/402/429/500,
  - stream data-parts a persistencia bez duplicít.
- Playwright E2E bez volania plateného modelu (mockovaný stream):
  - čistý browser → `/chat` → composer,
  - odoslanie user správy → tokenový stream assistant odpovede,
  - reload → obe správy zostanú uložené,
  - Build/Plan odošle správny `mode`,
  - artifact data-part aktivuje canvas,
  - retry a edit nevytvoria zombie/duplicitné správy,
  - výpadok a následné obnovenie `/api/chat` zobrazí chybu a Retry funguje,
  - mobil 390 px: composer, Chat/Preview a nulový horizontálny overflow.
- Jeden voliteľný live Mistral smoke test označiť samostatne, aby nebežal pri každom CI spustení.

### 5. Ship gate a finálne overenie

- Rozšíriť chat ship suite tak, aby neprešla iba na základe existencie composera.
- Spustiť relevantné unit/component testy a chat Playwright suite.
- Overiť v live preview:
  - žiadna `/auth` brána,
  - žiadne browser page errors,
  - prvá správa streamuje,
  - artifact sa zobrazí v Preview,
  - reload zachová thread a správy.
- Po úspechu spustiť projektový `bun run ship` podľa OmniOps pravidiel; bez merge/push zásahu do `main`.

## Akceptačné kritériá

- `/chat` funguje v čistom browseri bez loginu a bez manuálneho refreshu.
- Chýbajúca/expirujúca session sa obnoví pred server funkciou aj AI requestom.
- Dočasný výpadok backendu nespôsobí technický Unauthorized ani bielu obrazovku.
- Správa sa odošle, streamuje, uloží a po reloade sa zobrazí presne raz.
- Build, Plan, tools, artifacts, retry/edit a mobilný layout majú automatické regresné testy.
- V browser konzole nie sú runtime chyby patriace `/chat` flow.
