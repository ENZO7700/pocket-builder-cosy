# Production Hardening Pass (v1.0)

Cieľ: posunúť builder na produkčnú úroveň bez zmeny alebo straty existujúcich funkcií. Žiadne nové produktové featury — len spoľahlivosť, bezpečnosť, výkon, observabilita a testovacia sieť okolo toho, čo už funguje.

## Overený stav

- `bun run ship` reťazí typecheck → unit → lint:gate → ship-gates → e2e:ship (`scripts/ship.ts`).
- E2E suite existuje: landing, ship-chat, full-journey, no-auth-gate, mobile-shell, palette, project-preview, public-routes, share-public.
- Model policy je Mistral-only v kóde (`src/lib/models.ts`, `resolveModelForMode`), ale staré migrácie majú stále `DEFAULT 'openai/gpt-5.5'` na `messages.model` a `agent_settings.default_model`; neskoršia migrácia iba prepisuje existujúce riadky, defaulty stĺpcov ostávajú OpenAI.

## Rozsah prác

### 1. Konzistencia model policy (dokončenie Mistral-only)
- Nová migrácia, ktorá zmení stĺpcové DEFAULT hodnoty na Mistral default (bez dotyku dát a bez zmeny schémy inak).
- Unit test, ktorý overí, že žiadny runtime kód ani DB default nevracia `openai/*`.

### 2. Odolnosť runtime cesty `/chat` a `/builder`
- Jednotné mapovanie chýb AI brány (401/402/429/5xx) na používateľské hlásenia + Retry; žiadne technické stacky v UI.
- Bounded backoff iba pre 429/5xx, terminálne stavy bez retry.
- Guard proti duplicitnému uloženiu správy pri retry/reconnect (potvrdiť existujúci a pokryť testom).
- Timeout policy: žiadne umelé aborty na streamovaných volaniach.

### 3. Bezpečnosť
- Prejsť RLS a GRANT na všetkých public tabuľkách (`threads`, `messages`, `artifacts`, `artifact_versions`, `agent_settings`, `thread_memory`) a doplniť chýbajúce.
- Overiť, že verejné artefakt routy (`/a/$artifactId`, `preview`, embed) neexponujú cudzie dáta a majú sandbox iframe + CSP hlavičky.
- Kontrola, že žiadny secret nekončí v klientskom bundle (grep + test na `VITE_` povrch).

### 4. Výkon a UX stabilita
- Code-splitting ťažkých častí (Monaco, builder playground) cez lazy import, aby landing a `/chat` mali malý initial bundle.
- Mobilná kontrola 390 px: nulový horizontálny overflow na všetkých hlavných routách.
- Kontrola CLS na landingu a chat shelli.

### 5. Observabilita
- Štruktúrované serverové logy s fázou zlyhania a thread ID (nikdy token/secret).
- `/api/ai-status` rozšíriť o build info a stav providera pre smoke testy.

### 6. Testovacia sieť (regresné poistky)
- Unit: model resolver, error mapping, dedup, session bootstrap (jeden zdieľaný bootstrap pri paralelných volaniach).
- E2E (mockovaný stream, bez platených volaní): odoslanie správy → stream → reload → persistencia; artifact → canvas preview; share link; mobil 390 px.
- Rozšíriť `scripts/e2e-ship.ts` o mobile-shell a share-public, aby ship gate chytil regresie.

### 7. Dokumentácia a release
- Aktualizovať `README.md`, `docs/runbooks/daily-dev.md` a `CHANGELOG.md` o nový hardening pass.
- Finálny `bun run ship` + prod smoke (`/api/ai-status`, `/chat`).

## Technické poznámky

- Práca prebehne na `developeredit`, merge do `main` iba cez PR na explicitný pokyn.
- Žiadne auth brány sa nezavádzajú; `/auth` ostáva natrvalo odstránené.
- Žiadne zmeny produktového správania — každá zmena musí prejsť existujúcimi testami bez ich zoslabenia.

## Akceptačné kritériá

- `bun run ship` prejde zeleno vrátane rozšírenej e2e sady.
- Žiadny `openai/*` default nikde (kód aj DB).
- Každá public tabuľka má RLS + explicitné GRANTy.
- `/chat` funguje po reloade, pri výpadku brány zobrazí zrozumiteľnú chybu s Retry.
- Na 390 px žiadny horizontálny scroll a žiadne runtime chyby v konzole.
